<?php //$_SERVER['HTTPS'] == "off" ? $http = "https://" : $http = "https://";
$http = isset($_SERVER["HTTPS"]) ? 'https' : 'http';
$EMAIL_LINK=$http.$_SERVER['SERVER_NAME']."/"; echo $EMAIL_LINK;
$conn = mysql_connect("localhost","palavabook_cpark","PalavaB00kCP@rk!123");
$select_db =mysql_select_db("palavabook_cpark",$conn) or die("Unable to Connect to database");
if(!$select_db)
	{
		echo mysql_error();
		exit();
	}
?>
