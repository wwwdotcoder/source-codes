<?php
$pdf = new FPDI();

for($i=1;$i<=12;$i++){
			//$pdf->Rect(5, 5, 200, 287, 'D');

$pdf->AddPage();
//$pdf->Image("images/lodhalogo.jpg",15.5, 20.5);
$pdf->setSourceFile('ApplicationForm.pdf');

$tplIdx = $pdf->importPage($i);
$pdf->useTemplate($tplIdx, 0, 0, 0);

if($i == 2){
	$pdf->SetFont('Arial');
	$pdf->SetTextColor(0,0,0);

	$pdf->SetXY(8,9);
	$pdf->Write(0, $application_no);
				
	/* $pdf->SetXY(9,9);
	$pdf->Write(0, date('d'));
	
	$pdf->SetXY(10, 9); 
	$pdf->Write(0, date('m')); */
}			
}//total pages

$filepath2 = "Gapplications/Application_form_".$row['primary_applicant_firstname']."_".$application_no.".pdf";

$new_link2 = str_replace(" ","_",$filepath2);

$pdf->Output($new_link2,'F'); 

?>