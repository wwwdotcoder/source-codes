<?php
$pdf = new FPDI();
$pdf->AddPage();
$pdf->Image("images/logo.jpg",15.5, 20.5);

$pdf->SetFont('Arial','',13);
$pdf->SetTextColor(0,0,0);

$pdf->SetXY(100.5, 25.5);
$pdf->Write(0,"Application Number : ");
$pdf->SetXY(150.5, 25.5);
$pdf->Write(0,$application_no); 

$y_axis = 45.5;

$pdf->SetXY(15.5, $y_axis);
$pdf->Write(0,"Source : ");
$pdf->SetXY(60.5, $y_axis);
$pdf->Write(0,":");
$pdf->SetXY(70.5, $y_axis);
$pdf->Write(0,$row['booking_source']);

 if($row['booking_source']=="Channel Partner"){
	$pdf->SetXY(15.5, $y_axis+10);
	$pdf->Write(0,"REAP ID");
	$pdf->SetXY(60.5, $y_axis+10);
	$pdf->Write(0,":");
	$pdf->SetXY(70.5, $y_axis+10);
	$pdf->Write(0,$row['reap']);
	$y_axis= 75.5;
}else{
	$y_axis= 55.5;
}
$pdf->SetXY(15.5, $y_axis);
$pdf->Write(0,"Applicant Name");
$pdf->SetXY(60.5, $y_axis);
$pdf->Write(0,":");
$pdf->SetXY(70.5, $y_axis);
$pdf->Write(0,$applicant_name);

$pdf->SetXY(15.5, $y_axis+10);
$pdf->Write(0,"Mobile No.");
$pdf->SetXY(60.5, $y_axis+10);
$pdf->Write(0,":");
$pdf->SetXY(70.5, $y_axis+10);
$pdf->Write(0,$row['mobile_no']);

$pdf->SetXY(15.5, $y_axis+20);
$pdf->Write(0,"Email ID");
$pdf->SetXY(60.5, $y_axis+20);
$pdf->Write(0,":");
$pdf->SetXY(70.5, $y_axis+20);
$pdf->Write(0,$row['email']);

if($row['address2'] == ""){
	$address2 = "";
}else{
	$address2 = " , ".$row['address2'];
}
$pdf->SetXY(15.5, $y_axis+30);
$pdf->Write(0,"Address");
$pdf->SetXY(60.5, $y_axis+30);
$pdf->Write(0,":");
$pdf->SetXY(70.5, $y_axis+30);
$pdf->Write(0,$row['address']);

//$Address = $row['address'].$address2." , ".$row['address_country']." , ".$row['address_state']." , ".$row['address_city']." ".$row['address_pin'];

$pdf->SetXY(15.5, $y_axis+36);
$pdf->Write(0," ");
$pdf->SetXY(60.5, $y_axis+36);
$pdf->Write(0," ");
$pdf->SetXY(70.5, $y_axis+36);
$pdf->Write(0,$row['address2']);

$pdf->SetXY(15.5, $y_axis+45);
$pdf->Write(0," ");
$pdf->SetXY(60.5, $y_axis+45);
$pdf->Write(0," ");
$pdf->SetXY(70.5, $y_axis+45);
$pdf->Write(0,$row['address_state']." , ".$row['address_country']);

$pdf->SetXY(15.5, $y_axis+51);
$pdf->Write(0," ");
$pdf->SetXY(60.5, $y_axis+51);
$pdf->Write(0,"  ");
$pdf->SetXY(70.5, $y_axis+51);
$pdf->Write(0,$row['address_city']);

$pdf->SetXY(15.5, $y_axis+57);
$pdf->Write(0," ");
$pdf->SetXY(60.5, $y_axis+57);
$pdf->Write(0," ");
$pdf->SetXY(70.5, $y_axis+57);
$pdf->Write(0,$row['address_pin']);


if($row['jodi'] == "1BHK"){
	$jodi = "1 BHK";
}elseif($row['jodi'] == "2BHK Optima"){
	$jodi = "2 BHK Optima";
}elseif($row['jodi'] == "2BHK Ultima"){
	$jodi = "2 BHK Ultima";
}else{
	$jodi = "3 BHK";
}
 
$pdf->SetXY(15.5, $y_axis+80);
$pdf->Write(0,"Booking Type");
$pdf->SetXY(60.5, $y_axis+80);
$pdf->Write(0,":");
$pdf->SetXY(70.5, $y_axis+80);
$pdf->Write(0,$jodi);

$pdf->SetXY(15.5, $y_axis+100);
$pdf->Write(0,"Transaction Details");

$pdf->SetXY(15.5, $y_axis+120);
$pdf->Write(0,"Transaction No.");
$pdf->SetXY(60.5, $y_axis+120);
$pdf->Write(0,":");
$pdf->SetXY(70.5, $y_axis+120);
$pdf->Write(0,$payment_unique_transaction_no);
$pdf->SetXY(15.5, $y_axis+130);
$pdf->Write(0,"Payment Mode");
$pdf->SetXY(60.5, $y_axis+130);
$pdf->Write(0,":");
$pdf->SetXY(70.5, $y_axis+130);
$pdf->Write(0,$payment_mode);

$pdf->SetXY(15.5, $y_axis+140);
$pdf->Write(0,"Date Time Stamp"); 
$pdf->SetXY(60.5, $y_axis+140);
$pdf->Write(0,":");
$pdf->SetXY(70.5, $y_axis+140);
$pdf->Write(0,$date." ".$time); 

$pdf->SetXY(15.5, $y_axis+150);
$pdf->Write(0,"Amount"); 
$pdf->SetXY(60.5, $y_axis+150);
$pdf->Write(0,":");
$pdf->SetXY(70.5, $y_axis+150);
$pdf->Write(0,$payment_amount); 

$filepath1 = "receipt/Receipt_".$row['primary_applicant_firstname']."_".$application_no.".pdf";

$new_link1 = str_replace(" ","_",$filepath1);

$pdf->Output($new_link1,'F'); 

?>