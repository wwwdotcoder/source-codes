<?php 
session_start();
date_default_timezone_set("Asia/Kolkata");
if (!isset($_SESSION["datetime"])){ 
$_SESSION["datetime"] = date('d-m-Y H:i:s');
}
if (!isset($_SESSION["pixel_timestamp"])){ 

if($_GET['vserv'] != ''){
	$_SESSION["pixel_timestamp"] = $_GET['vserv'];
}else{
	$t = microtime(true);
	$micro = sprintf("%06d",($t - floor($t)) * 1000000);
	$d = new DateTime( date('Y-m-d H:i:s.'.$micro, $t) ); 
	$_SESSION["pixel_timestamp"] = strtotime($d->format("Y-m-d H:i:s.u"));
}
} 
if (!isset($_SESSION["publisher"])){  
	$_SESSION["publisher"] = @$_GET["publisher"];
}
require_once 'request-handler.php'; ?>
<?php
	if($mtitle == ''){ $mtitle = 'LODHA ';}
	if($mdesc == ''){ $mdesc = 'LODHA';}
	if($mkey == ''){ $mkey = 'LODHA';}
	
#canonical_tag	
$https = $_SERVER['HTTPS'] == 'on' ? 'https://' : 'http://';
$server = $_SERVER['HTTP_HOST'];
$file = $_SERVER['SCRIPT_NAME'];

if($file == '/bigwin/index.php'){
	$file = '/bigwin/';
}
$canonical_tag = $https.$server.$file;
#canonical_tag END		
?>
<!DOCTYPE html>
<html lang="en" dir="ltr">
<!--[if IE 7 ]><html lang="en-gb" dir="ltr" class="ie7 ltr"><![endif]-->
<!--[if IE 8 ]><html lang="en-gb" dir="ltr" class="ie8 ltr"><![endif]-->
<!--[if IE 9 ]><html lang="en-gb" dir="ltr" class="ie9 ltr"><![endif]-->
<!--[if IEMobile 7 ]><html lang="en-gb" dir="ltr" class="iem7 ltr"><![endif]-->
<!--[if (gt IE 9)|!(IE)|(gt IEMobile 7)|!(IEMobile) ]><!-->
    <head>
		<link rel="canonical" href="<?=@$canonical_tag;?>" />
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge,chrome=1">
        <title><?php echo $mtitle; ?></title>
        <meta name="Description" content="<?php echo $mdesc; ?>">
        <meta name="Keywords" content="<?php echo $mkey; ?>">
        <meta name="viewport" content="width=device-width, initial-scale=1">
		
		<link rel="shortcut icon" href="<?php echo CDN; ?>new/bigwin/favicon.png">
        <link type="text/css" rel="stylesheet" href="<?php echo ASSETS; ?>css/reset.css">
        <link type="text/css" rel="stylesheet" href="<?php echo ASSETS; ?>css/jquery.bxslider.css">
        <link type="text/css" rel="stylesheet" href="<?php echo ASSETS; ?>css/style.css">
        <link type="text/css" rel="stylesheet" href="<?php echo ASSETS; ?>css/devices.css">
		<link type="text/css" rel="stylesheet" href="<?php echo ASSETS; ?>css/text-effect.css">
		<link type="text/css" rel="stylesheet" href="<?php echo ASSETS; ?>css/lightgallery.css">
        <link rel="stylesheet" type="text/css" href="//cdn.jsdelivr.net/rupyainr/1.0.0/rupyaINR.min.css?5f3697">
		<link rel="stylesheet" type="text/css" href="<?php echo ASSETS; ?>css/jquery.fancybox-1.3.4.css" media="screen" />
		
<script type="text/javascript" src="<?=CDN;?>plugins/jquery.min.js"></script>

<!-- Google Tag Manager - dataLayer Object Place this code just before </head> tag -->
<script> dataLayer = []; </script>
<!-- End dataLayer Object -->

<!-- Google Tag Manager - dataLayer Object Place this code just before </head> tag -->
<script>(function(w,d,s,l,i){w[l]=w[l]||[];w[l].push({'gtm.start': new Date().getTime(),event:'gtm.js'});var f=d.getElementsByTagName(s)[0],j=d.createElement(s),dl=l!='dataLayer'?'&l='+l:'';j.async=true;j.src='//www.googletagmanager.com/gtm.js?id='+i+dl;f.parentNode.insertBefore(j,f); })(window,document,'script','dataLayer','GTM-Q8FF');</script>
<!-- End Google Tag Manager -->

</head>
<body>
<!--Google Tag Manager Noscript Place this code in <body>-->
<noscript><iframe src="//www.googletagmanager.com/ns.html?id=GTM-Q8FF" height="0" width="0" style="display:none;visibility:hidden"></iframe></noscript>
<!-- End Google Tag Manager Noscript-->
<?php $cookie_name = COOKIE_NAME;
	require_once '../cookie-code.php';
?>