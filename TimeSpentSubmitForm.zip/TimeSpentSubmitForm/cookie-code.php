<?php session_start();
date_default_timezone_set("Asia/Kolkata"); 
if (!isset($_SESSION["datetime"])){ 
$_SESSION["datetime"] = date('d-m-Y H:i:s');
}
$server = $_SERVER['HTTP_HOST'];
if (!isset($_COOKIE[$cookie_name.'_publisher'])) 
	{
		$publisher = $_GET['publisher'];
		$campaign = $_GET['campaign'];
		$banner_size = $_GET['banner_size'];
		$digital_source = $_GET['digital_source'];
		$digital_medium = $_GET['digital_medium'];
		$keyword = $_GET['keyword'];
		$placement = $_GET['placement'];
		$adgroup = $_GET['adgroup'];
		$adposition = $_GET['adposition'];
		$matchtype = $_GET['matchtype'];
		$network = $_GET['network'];
		$gclid = $_GET['gclid'];
		$visitor_type = $_GET['visitor_type'];
		
    if ($publisher == ""){
		//$publisher = $_SERVER['SERVER_NAME'];
		$HTTP_REFERER = $_SERVER["HTTP_REFERER"];
		$explode_server = explode(".",$server);
		//echo $HTTP_REFERER.",". $server."===";
		if($HTTP_REFERER == ""){
				$publisher = "Direct-".$explode_server[1].".".$explode_server[2];
				$campaign = "Direct";
			}else{
				if (strpos($HTTP_REFERER, 'google') !== false) {	
					$publisher = "Organic-Search-GOO-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Search";
				}
				else if (strpos($HTTP_REFERER, 'bing') !== false) {
					$publisher = "Organic-Search-BIN-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Search";
				}
				else if (strpos($HTTP_REFERER, 'yahoo') !== false) {
					$publisher = "Organic-Search-YAH-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Search";
				}
				else if (strpos($HTTP_REFERER, 'ask') !== false) {
					$publisher = "Organic-Search-ASK-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Search";
				}
				elseif (strpos($HTTP_REFERER, 'facebook') !== false) {
					$publisher = "Facebook-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Social";
				}
				elseif (strpos($HTTP_REFERER, 'twitter') !== false) {
					$publisher = "Twitter-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Social";
				}
				elseif (strpos($HTTP_REFERER, 'instagram') !== false) {
					$publisher = "Instagram-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Social";
				}
				elseif (strpos($HTTP_REFERER, 'linkedin') !== false) {
					$publisher = "LinkedIn-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Social";
				}
				else{
					$publisher = "Organic-Referral-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Referral";
					$placement = $HTTP_REFERER;
				}
				
			}
	}
			$Month = 2592000 + time();
			setcookie($cookie_name.'_publisher', $publisher, $Month);
			setcookie($cookie_name.'_campaign', $campaign, $Month);
			setcookie($cookie_name.'_banner_size', $banner_size, $Month);
			setcookie($cookie_name.'_digital_source', $digital_source, $Month);
			setcookie($cookie_name.'_digital_medium', $digital_medium, $Month);
			setcookie($cookie_name.'_keyword', $keyword, $Month);
			setcookie($cookie_name.'_placement', $placement, $Month);
			setcookie($cookie_name.'_adgroup', $adgroup, $Month);
			setcookie($cookie_name.'_adposition', $adposition, $Month);
			setcookie($cookie_name.'_matchtype', $matchtype, $Month);
			setcookie($cookie_name.'_network', $network, $Month);
			setcookie($cookie_name.'_gclid', $gclid, $Month);
			setcookie($cookie_name.'_visitor_type', $visitor_type, $Month);
    if ($_COOKIE[$cookie_name."_publisher"] == '') 
		{
			$_COOKIE[$cookie_name."_publisher"] = $publisher;
			$_COOKIE[$cookie_name."_campaign"] = $campaign;
			$_COOKIE[$cookie_name."_banner_size"] = $banner_size;
			$_COOKIE[$cookie_name."_digital_source"] = $digital_source;
			$_COOKIE[$cookie_name."_digital_medium"] = $digital_medium;
			$_COOKIE[$cookie_name."_keyword"] = $keyword;
			$_COOKIE[$cookie_name."_placement"] = $placement;
			$_COOKIE[$cookie_name."_adgroup"] = $adgroup;
			$_COOKIE[$cookie_name."_adposition"] = $adposition;
			$_COOKIE[$cookie_name."_matchtype"] = $matchtype;
			$_COOKIE[$cookie_name."_network"] = $network;
			$_COOKIE[$cookie_name."_gclid"] = $gclid;
			$_COOKIE[$cookie_name."_visitor_type"] = $visitor_type;
		}
	}
	//echo $_COOKIE[$cookie_name."_publisher"].")))";
	if (isset($_COOKIE[$cookie_name."_publisher"])) 
	{
		
		$publisher1 = $_GET['publisher'];
		$campaign1 = $_GET['campaign'];
		$banner_size = $_GET['banner_size'];
		$digital_source = $_GET['digital_source'];
		$digital_medium = $_GET['digital_medium'];
		$keyword = $_GET['keyword'];
		$placement = $_GET['placement'];
		$adgroup = $_GET['adgroup'];
		$adposition = $_GET['adposition'];
		$matchtype = $_GET['matchtype'];
		$network = $_GET['network'];
		$gclid = $_GET['gclid'];
		$visitor_type = $_GET['visitor_type'];
		
	  if ($publisher1 == ""){
		$HTTP_REFERER = $_SERVER["HTTP_REFERER"];
		$explode_server = explode(".",$server);
		
		if(strpos($HTTP_REFERER, $server) === false){
		
			if($HTTP_REFERER == ""){
				$publisher = "Direct-".$explode_server[1].".".$explode_server[2];
				$campaign = "Direct";
			}else{
				if (strpos($HTTP_REFERER, 'google') !== false) {
					$publisher = "Organic-Search-GOO-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Search";
				}
				else if (strpos($HTTP_REFERER, 'bing') !== false) {
					$publisher = "Organic-Search-BIN-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Search";
				}
				else if (strpos($HTTP_REFERER, 'yahoo') !== false) {
					$publisher = "Organic-Search-YAH-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Search";
				}
				else if (strpos($HTTP_REFERER, 'ask') !== false) {
					$publisher = "Organic-Search-ASK-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Search";
				}
				elseif (strpos($HTTP_REFERER, 'facebook') !== false) {
					$publisher = "Facebook-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Social";
				}
				elseif (strpos($HTTP_REFERER, 'twitter') !== false) {
					$publisher = "Twitter-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Social";
				}
				elseif (strpos($HTTP_REFERER, 't.co') !== false) {
					$publisher = "Twitter-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Social";
				}
				elseif (strpos($HTTP_REFERER, 'instagram') !== false) {
					$publisher = "Instagram-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Social";
				}
				elseif (strpos($HTTP_REFERER, 'linkedin') !== false) {
					$publisher = "LinkedIn-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Social";
				}
				else{
					$publisher = "Organic-Referral-".$explode_server[1].".".$explode_server[2];
					$campaign = "Organic-Referral";
					$placement = $HTTP_REFERER;
				}
				
			}
			//echo $publisher."===".$campaign."%%";
			$Month = 2592000 + time();
			setcookie($cookie_name.'_publisher', $publisher, $Month);
			setcookie($cookie_name.'_campaign', $campaign, $Month);
			setcookie($cookie_name.'_adgroup', $adgroup, $Month);
			$_COOKIE[$cookie_name."_publisher"] = $publisher;
			$_COOKIE[$cookie_name."_campaign"] = $campaign;
			$_COOKIE[$cookie_name."_adgroup"] = $adgroup;
		}
	}  
		
    if ($publisher1 != "" || $campaign1 != "") 
		{
			//echo $_COOKIE[$cookie_name."_publisher"] ."!=". $publisher1;
        if ($_COOKIE[$cookie_name."_publisher"] != $publisher1) 
		{
            $Month = 2592000 + time();
            $_COOKIE[$cookie_name."_publisher"] = $publisher1;
            $_COOKIE[$cookie_name."_campaign"] = $campaign1;
			$_COOKIE[$cookie_name."_banner_size"] = $banner_size;
			$_COOKIE[$cookie_name."_digital_source"] = $digital_source;
			$_COOKIE[$cookie_name."_digital_medium"] = $digital_medium;
			$_COOKIE[$cookie_name."_keyword"] = $keyword;
			$_COOKIE[$cookie_name."_placement"] = $placement;
			$_COOKIE[$cookie_name."_adgroup"] = $adgroup;
			$_COOKIE[$cookie_name."_adposition"] = $adposition;
			$_COOKIE[$cookie_name."_matchtype"] = $matchtype;
			$_COOKIE[$cookie_name."_network"] = $network;
			$_COOKIE[$cookie_name."_gclid"] = $gclid;
			$_COOKIE[$cookie_name."_visitor_type"] = $visitor_type;
			
            setcookie($cookie_name.'_publisher', $publisher1, $Month);
            setcookie($cookie_name.'_campaign', $campaign1, $Month);
			setcookie($cookie_name.'_banner_size', $banner_size, $Month);
			setcookie($cookie_name.'_digital_source', $digital_source, $Month);
			setcookie($cookie_name.'_digital_medium', $digital_medium, $Month);
			setcookie($cookie_name.'_keyword', $keyword, $Month);
			setcookie($cookie_name.'_placement', $placement, $Month);
			setcookie($cookie_name.'_adgroup', $adgroup, $Month);
			setcookie($cookie_name.'_adposition', $adposition, $Month);
			setcookie($cookie_name.'_matchtype', $matchtype, $Month);
			setcookie($cookie_name.'_network', $network, $Month);
			setcookie($cookie_name.'_gclid', $gclid, $Month);
			setcookie($cookie_name.'_visitor_type', $visitor_type, $Month);
        }
		
        else
        
        //if same means google=google  then check campaign is same or not if not then overwrite campaign only
        {
            if ($_COOKIE[$cookie_name."_campaign"] != $campaign1) {
                $_COOKIE[$cookie_name."_campaign"] = $campaign1;
                setcookie($cookie_name.'_campaign', $campaign1, $Month);
				setcookie($cookie_name.'_banner_size', $banner_size, $Month);
				setcookie($cookie_name.'_digital_source', $digital_source, $Month);
				setcookie($cookie_name.'_digital_medium', $digital_medium, $Month);
				setcookie($cookie_name.'_keyword', $keyword, $Month);
				setcookie($cookie_name.'_placement', $placement, $Month);
				setcookie($cookie_name.'_adgroup', $adgroup, $Month);
				setcookie($cookie_name.'_adposition', $adposition, $Month);
				setcookie($cookie_name.'_matchtype', $matchtype, $Month);
				setcookie($cookie_name.'_network', $network, $Month);
				setcookie($cookie_name.'_gclid', $gclid, $Month);
				setcookie($cookie_name.'_visitor_type', $visitor_type, $Month);
            }
        }
    }
}
?>

<script type="application/javascript">
// To detect internet service provider
var currentdate = new Date(); 
var datetime =  currentdate.getDate() + "-"
                + (currentdate.getMonth()+1)  + "-" 
                + currentdate.getFullYear() + " "  
                + currentdate.getHours() + ":"  
                + currentdate.getMinutes() + ":" 
                + currentdate.getSeconds();
var onload_datetime = "<?php echo $_SESSION['datetime']; ?>";
<?php
if (!isset($_COOKIE["First_Visit__c"])) 
	{
?>				
//createCookie('First_Visit__c', datetime, 60);
<?php
	}
?>
function getCookie(cname) {
    var name = cname + "=";
    var ca = document.cookie.split(';');
    for(var i=0; i<ca.length; i++) {
        var c = ca[i];
        while (c.charAt(0)==' ') c = c.substring(1);
        if (c.indexOf(name) == 0) return c.substring(name.length,c.length);
    }
    return "";
}

//alert(getCookie('First_Visit__c'));
	function createCookie(name, value, days) {
    var date, expires;
    if (days) {
        date = new Date();
        date.setTime(date.getTime()+(days*24*60*60*1000));
        expires = "; expires="+date.toGMTString();
    } else {
        expires = "";
    }
    document.cookie = name+"="+value+expires+"; path=/";
	
}

</script>
<?php
 if (!isset($_COOKIE["First_Visit__c"])) 
	{
		$datetime = date("Y-m-d H:i:s");
		$number_of_days = 60 ;
		$date_of_expiry = time() + 60 * 60 * 24 * $number_of_days ;
		setcookie("First_Visit__c",$datetime,$date_of_expiry);
		$_COOKIE['First_Visit__c'] = $datetime;
		
	}
?>