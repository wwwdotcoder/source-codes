/**
 * Device Detection
 *
 * Set a CallBack function if
 * user agent is Mobile
 *
 * @author Neeraj Singh
 */
(function(JQ$) {
    JQ$.isMobAgent = function() {
        if ((/android|webos|iphone|ipad|ipod|blackberry|iemobile|opera mini/i.test(navigator.userAgent.toLowerCase()))) {
            return true;
        } else return false;
    };
}(jQuery));
/**

/**
 * CONTACT US
 *
 * SCRIPT START
 * -----------------------------------------------
 */
var varCode = '';
var j$ = jQuery.noConflict();
var SITE_URL = window.location.protocol + '//' + window.location.hostname + '/hyderabad-shining/';
var THANK_YOU = "thankyou.php";
/* This function handles the colon in VisualForce Ids */
function jq(myid) {
    return '#' + myid.replace(/(:|\.)/g, '\\$1');
}

function checkFirstCharacterPeriod(str) {
    return (str.substr(0, 1) != ".");
}

function checkFirstCharacterSpace(str) {
    return (str.substr(0, 1) != " ");
}

function isSpecialCharacter(s) {
    var iChars = "~`1234567890!@#$%^&*()+=-_[]\\\';,/{}|\":<>?";
    var flag = false;
    for (var i = 0; i < s.length; i++) {
        if (iChars.indexOf(s.charAt(i)) != -1) {
            flag = true;
        }
    }
    return flag;
}

function isSpecialCharacterwithPeriod(s) {
    var iChars = "~`1234567890!@#$%^&*()+=-_[]\\\';,./{}|\":<>?";
    var flag = false;
    for (var i = 0; i < s.length; i++) {
        if (iChars.indexOf(s.charAt(i)) != -1) {
            flag = true;
        }
    }
    return flag;
}

function getRandomNumber() {
    return Math.floor(Math.random() * 9000) + 1000;
}

JQ$(document).ready(function() {

    /* Plans Page Tab for Mobile */
    JQ$('.selectOption a').on('click', function() {
        JQ$('.plans #bx-pager').stop().slideToggle();
    });
    JQ$('.plans #bx-pager').hide();
    JQ$('.plans #bx-pager a').on('click', function() {
        var partNav = JQ$(this).text();
        JQ$('.plans .selectOption a span').text(partNav);
        JQ$(this).parent().stop().slideUp('fast');
    });
    JQ$('.plans .bx-controls-direction a').click(function() {
        var selectText = JQ$('.plans').find('#bx-pager').find('a.active').text();
        JQ$('.plans .selectOption a span').text(selectText);
    });

   /* Plans Page Tab for Desktop */
    /* JQ$("#tabSlider").tabs();
    JQ$("#slideA, #slideB, #slideC, #slideD").tabs({
        show: {
            effect: "fade",
            duration: 500
        }
    });

    JQ$('#lightgallery').lightGallery({
        mode: 'lg-fade'
    })
	JQ$('#lightgallery1').lightGallery({
        mode: 'lg-fade'
    })
	JQ$('#lightgallery2').lightGallery({
        mode: 'lg-fade'
    })
	JQ$('#lightgallery3').lightGallery({
        mode: 'lg-fade'
    }) */
	


    /* Share This - Social Media */
   JQ$(".Share_M, a.shareDetails").click(function(){
       JQ$(".socialMedia").slideToggle();
   });

    /**
     * Name Validation
     * @return {[type]} [description]
     */
    function validateName() {
        JQ$("#uname-err").hide();
        if (JQ$(jq(tfirstName)).val().length <= 0) {
            return false;
        }
        return true;
    }
    /**
     * Project Validation
     * @return {[type]} [description]
     */
    function validateProject() {
        JQ$("#pname-err").hide();
        if (JQ$(jq(tprojectName)).val() == 'None') {
            return false;
        }
        return true;
    }

    function validateName1() {
        JQ$("#uname-err1").hide();
        if ((JQ$(jq(tfirstName)).val().length > 0) && ((JQ$(jq(tfirstName)).val().substr(0, 1) == " ") || (JQ$(jq(tfirstName)).val().substr(0, 1) == ".") || (isSpecialCharacter(JQ$(jq(tfirstName)).val())))) {
            return false;
        }
        return true;
    }
    /**
     * email validation
     * @return {[type]} [description]
     */
    function validateEmailID() {
        JQ$("#emailid-err").hide();
        JQ$("#emailid1-err").hide();
        if (JQ$(jq(temailID)).val().length <= 0) {
            return false;
        }
        // else
        // {
        // var stremail = (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,5})+$/).test(JQ$(jq(temailID)).val());
        // if(stremail == false)
        // {                        
        // JQ$("#emailid1-err").show();    
        // return false;
        // }
        // }
        return true;
    }

    function validateEmailIDblank() {
        var stremail = (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,5})+$/).test(JQ$(jq(temailID)).val());
        if (stremail == false) {
            //JQ$("#emailid1-err").show();    
            return false;
        }
        return true;
    }
    /**
     * LandLine  Validation
     * @param  {[type]}  s [description]
     * @return {Boolean}   [description]
     */
    function isSpecialCharactermobile(s) {
        var iChars = "!@#$%^&*()+=-_[]\\\';,./{}|\":<>?";
        var flag = false;
        for (var i = 0; i < s.length; i++) {
            if (iChars.indexOf(s.charAt(i)) != -1) {
                flag = true;
            }
        }
        return flag;
    }

    /*
    function validate_stdcode() {
        if (JQ$(jq(tCountryList)).val() == "India" && JQ$(jq(tPhoneNumber1)).val().length > 0 && (JQ$(jq(tPhoneNumber1)).val().substr(0, 1) != "0")) {
            return false;
        }
        return true;
    }
    
    function valid_std_code() {
        if (JQ$(jq(tCountryList)).val() == "India" && JQ$(jq(tPhoneNumber1)).val().length > 0 && (isNaN(JQ$(jq(tPhoneNumber1)).val()) || (JQ$(jq(tPhoneNumber1)).val().substr(0, 1) == " "))) {
            return false;
        }
        return true;
    }

    
    function validate_landphone() {
        if (JQ$(jq(tCountryList)).val() == "India" && JQ$(jq(tPhoneNumber1)).val().length > 0 && JQ$(jq(tPhoneNumber2)).val().length == 0) {
            return false;
        }
        return true;
    }
   
    function validate_landphonestd() {
        if (JQ$(jq(tCountryList)).val() == "India" && JQ$(jq(tPhoneNumber2)).val().length > 0 && JQ$(jq(tPhoneNumber1)).val().length == 0) {
            return false;
        }
        return true;
    }
    
    function valid_landline_no() {
        if (JQ$(jq(tCountryList)).val() == "India" && JQ$(jq(tPhoneNumber2)).val().length > 0 && (isNaN(JQ$(jq(tPhoneNumber2)).val()) || (JQ$(jq(tPhoneNumber2)).val().substr(0, 1) == " ") || (JQ$(jq(tPhoneNumber2)).val().substr(0, 1) == 0))) {
            return false;
        }
        return true;
    }

   
    function validate_landlinephone() {
        if (JQ$(jq(tCountryList)).val() == "India" && JQ$(jq(tPhoneNumber1)).val().length > 0 && JQ$(jq(tPhoneNumber2)).val().length > 0) {
            if ((JQ$(jq(tPhoneNumber1)).val().length + JQ$(jq(tPhoneNumber2)).val().length) != 11) return false;
        }
        return true;
    }
    */

    /**
     * Landline Validation NoN India
     * @return {[type]} [description]
     */
    function stdcodeNaN() {
        if (JQ$(jq(tCountryList)).val() != "India" && JQ$(jq(tPhoneNumber1)).val().length > 0 && (isNaN(JQ$(jq(tPhoneNumber1)).val()) || (JQ$(jq(tPhoneNumber1)).val().substr(0, 1) == "0"))) //coment out 0 from std code
        {
            return false;
        }
        return true;
    }

    function Landline_null_nonindia_() {
        if (JQ$(jq(tCountryList)).val() != "India" && JQ$(jq(tPhoneNumber1)).val().length > 0 && JQ$(jq(tPhoneNumber2)).val().length == 0) {
            return false;
        }
        return true;
    }

    function std_null_nonindia() {
        if (JQ$(jq(tCountryList)).val() != "India" && JQ$(jq(tPhoneNumber1)).val().length == 0 && JQ$(jq(tPhoneNumber2)).val().length > 0) {
            return false;
        }
        return true;
    }

    function landlineNaN() {
        if (JQ$(jq(tCountryList)).val() != "India" && JQ$(jq(tPhoneNumber2)).val().length > 0 && (isNaN(JQ$(jq(tPhoneNumber2)).val()) || (JQ$(jq(tPhoneNumber2)).val().substr(0, 1) == " ") || (JQ$(jq(tPhoneNumber2)).val().substr(0, 1) == 0))) {
            return false;
        }
        return true;
    }
    /**
     * Country validation
     * @return {[type]} [description]
     */
    function validateCountry() {
        if (JQ$(jq(tCountryList)).val() == "None"  || JQ$(jq(tCountryList)).val().length == 0 ) {
            return false;
        }
        return true;
    }
    /**
     * City Validation
     * @return {[type]} [description]
     */
 function validateCity() {
        JQ$("#city-err1").hide();
        JQ$("#state-err").hide();
        if ((JQ$(jq(tCountryList)).val() == "India" || JQ$(jq(tCountryList)).val() == "United Kingdom"  || JQ$(jq(tCountryList)).val() == "United Arab Emirates" || JQ$(jq(tCountryList)).val() == "Saudi Arabia" || JQ$(jq(tCountryList)).val() == "Kuwait"  || JQ$(jq(tCountryList)).val() == "Singapore" || JQ$(jq(tCountryList)).val() == "Hong Kong"  || JQ$(jq(tCountryList)).val() == "China") && (JQ$(jq(tCity)).val() == "None" || JQ$(jq(tCity)).val().length == 0)) {
            return false;
        }
        if (JQ$(jq(tCountryList)).val() == "United States" && (JQ$(jq(tState)).val() == "" || JQ$(jq(tState)).length == 0) && (JQ$(jq(trecvalue)).val() == "Residential")) {
            return false;
        }
        return true;
    }
    /**
     * City Text Validation Code
     * @return {[type]} [description]
     */
    function validateCity_Text() {
        JQ$("#city-err").hide();
        if (JQ$(jq(tCountryList)).val() != "India" && JQ$(jq(tCountryList)).val() != "United States"  && JQ$(jq(tCountryList)).val() != "United Kingdom" && JQ$(jq(tCountryList)).val() != "United Arab Emirates" && JQ$(jq(tCountryList)).val() != "Saudi Arabia" && JQ$(jq(tCountryList)).val() != "Kuwait"  && JQ$(jq(tCountryList)).val() != "Singapore" && JQ$(jq(tCountryList)).val() != "Hong Kong"  && JQ$(jq(tCountryList)).val() != "China" && (JQ$(jq(tCityText)).val().length <= 0 || JQ$(jq(tCityText)).val().length == 0)) {
            return false;
        }
        if (JQ$(jq(tCountryList)).val() != "India" && JQ$(jq(tCountryList)).val() != "United States"  && JQ$(jq(tCountryList)).val() != "United Kingdom" && JQ$(jq(tCountryList)).val() != "United Arab Emirates" && JQ$(jq(tCountryList)).val() != "Saudi Arabia" && JQ$(jq(tCountryList)).val() != "Kuwait"  && JQ$(jq(tCountryList)).val() != "Singapore" && JQ$(jq(tCountryList)).val() != "Hong Kong"  && JQ$(jq(tCountryList)).val() != "China" && (JQ$(jq(tCityText)).val().length == 0 || JQ$(jq(tCityText)).val().length == 0) && JQ$(jq(trecvalue)).val() != "Residential") {
            return false;
        }
        if (JQ$(jq(tCountryList)).val() != "India" && JQ$(jq(tCountryList)).val() == "United States"  && JQ$(jq(tCountryList)).val() != "United Kingdom" && JQ$(jq(tCountryList)).val() != "United Arab Emirates" && JQ$(jq(tCountryList)).val() != "Saudi Arabia" && JQ$(jq(tCountryList)).val() != "Kuwait"  && JQ$(jq(tCountryList)).val() != "Singapore" && JQ$(jq(tCountryList)).val() != "Hong Kong"  && JQ$(jq(tCountryList)).val() != "China" && (JQ$(jq(tCityText)).val().length == 0) && JQ$(jq(trecvalue)).val() != "Residential") {
            return false;
        }
        return true;
    }

    function validateCity_Text1() {
        JQ$("#city-err2").hide();
        if ((JQ$(jq(tCountryList)).val() != "India" && JQ$(jq(tCountryList)).val() == "United States"  && JQ$(jq(tCountryList)).val() != "United Kingdom" && JQ$(jq(tCountryList)).val() != "United Arab Emirates" && JQ$(jq(tCountryList)).val() != "Saudi Arabia" && JQ$(jq(tCountryList)).val() != "Kuwait"  && JQ$(jq(tCountryList)).val() != "Singapore" && JQ$(jq(tCountryList)).val() != "Hong Kong"  && JQ$(jq(tCountryList)).val() != "China" && JQ$(jq(trecvalue)).val() != "Residential") && (JQ$(jq(tCityText)).val().length > 0) && ((JQ$(jq(tCityText)).val().substr(0, 1) == " ") || (isSpecialCharacterwithPeriod(JQ$(jq(tCityText)).val())))) {
            return false;
        }
        if ((JQ$(jq(tCountryList)).val() != "India" && JQ$(jq(tCountryList)).val() != "United States"  && JQ$(jq(tCountryList)).val() != "United Kingdom" && JQ$(jq(tCountryList)).val() != "United Arab Emirates" && JQ$(jq(tCountryList)).val() != "Saudi Arabia" && JQ$(jq(tCountryList)).val() != "Kuwait"  && JQ$(jq(tCountryList)).val() != "Singapore" && JQ$(jq(tCountryList)).val() != "Hong Kong"  && JQ$(jq(tCountryList)).val() != "China" && JQ$(jq(trecvalue)).val() != "Residential") && (JQ$(jq(tCityText)).val().length > 0) && ((JQ$(jq(tCityText)).val().substr(0, 1) == " ") || (isSpecialCharacterwithPeriod(JQ$(jq(tCityText)).val())))) {
            return false;
        }
        if (JQ$(jq(tCountryList)).val() != "India" && JQ$(jq(tCountryList)).val() != "United States"  && JQ$(jq(tCountryList)).val() != "United Kingdom" && JQ$(jq(tCountryList)).val() != "United Arab Emirates" && JQ$(jq(tCountryList)).val() != "Saudi Arabia" && JQ$(jq(tCountryList)).val() != "Kuwait"  && JQ$(jq(tCountryList)).val() != "Singapore" && JQ$(jq(tCountryList)).val() != "Hong Kong"  && JQ$(jq(tCountryList)).val() != "China" && (JQ$(jq(tCityText)).val().length <= 0 || isSpecialCharacter(JQ$(jq(tCityText)).val()))) {
            return false;
        }
        return true;
    } 
    /**
     * DesignationCompanyName Validation
     * @return {[type]} [description]
     */
    function validateDesignationCompanyName() {
        var objCompanyDesignation = document.getElementById("j_id0:enq_frm:pageblock1:DesCompanyMandatory");
        if (objCompanyDesignation.value == 1) {
            if (JQ$(jq(tDesignation)).val().length <= 0 || JQ$(jq(tCompanyName)).val().length <= 0) {
                if (JQ$(jq(tDesignation)).val().length <= 0) {}
                if (JQ$(jq(tCompanyName)).val().length <= 0) {}
                return false;
            }
        }
        return true;
    }
    /**
     * Mobile Validation
     * @return {[type]} [description]
     */
    function validateMobileLandLine() {
        JQ$("#mobile-err").hide();
        JQ$("#mobile_zero").hide();
        JQ$("#mobile_max").hide();
        JQ$("#mobile-err1").hide();
        if (JQ$(jq(tMobileNumber)).val().length <= 0) {
            //JQ$("#mobile-err").show();
            return false;
        }
        // if (JQ$(jq(tMobileNumber)).val().substr(0, 1) == "0")
        // {
        // //JQ$("#mobile_zero").show();
        // return false;
        // }
        // if(JQ$(jq(tCountryList)).val()=="India")
        // {
        // 
        // if (JQ$(jq(tMobileNumber)).val().length<10 || JQ$(jq(tMobileNumber)).val().length>11)
        // {
        // //JQ$("#mobile_max").hide();
        // return false;
        // }
        // } 
        return true;
    }

    function MobileNumberStartswithzero() {
        if ((JQ$(jq(tMobileNumber)).val().substr(0, 1) == "0") && (JQ$(jq(tCountryList)).val() == "India")) {
            return false;
        }
        return true;
    }

    function MobileNumberIndia() {
        if (JQ$(jq(tCountryList)).val() == "India") {
            if (JQ$(jq(tMobileNumber)).val().length < 10 || JQ$(jq(tMobileNumber)).val().length > 10) {
                return false;
            }
        }
        return true;
    }

    function valid_mobile_no() {
        if (isSpecialCharactermobile(JQ$(jq(tMobileNumber)).val()) || isNaN(JQ$(jq(tMobileNumber)).val()) || JQ$(jq(tMobileNumber)).val().substr(0, 1) == " ") {
            return false;
        }
        return true;
    }

    function IsNumeric(keyCode, e) {
        if (keyCode == 9) {} else {
            e.preventDefault ? e.preventDefault() : e.returnValue = false;
            return false;
        }
    }

    function RestrictPeriod(keyCode, e) {
        if (keyCode != 190) {} else {
            e.preventDefault ? e.preventDefault() : e.returnValue = false;
            return false;
        }
    }
    JQ$(jq(tMobileNumber)).keydown(function(event) {
        RestrictPeriod(event.keyCode, event);
    });
    JQ$(jq(tPhoneNumber1)).keydown(function(event) {
        RestrictPeriod(event.keyCode, event);
    });
    JQ$(jq(tPhoneNumber2)).keydown(function(event) {
        RestrictPeriod(event.keyCode, event);
    });
    JQ$(jq(tMobileNumber)).keyup(function() {
        JQ$.fn.checkNumber(JQ$(this)[0]);
    });
    JQ$(jq(tMobileNumber)).keydown(function() {
        JQ$.fn.checkNumber(JQ$(this)[0]);
    });
    // Preventing user from entering special characters
    JQ$.fn.checkNumber = function(val) {
        function CalcKeyCode(aChar) {
            var character = aChar.substring(0, 1);
            var code = aChar.charCodeAt(0);
            return code;
        }
        var strPass = val.value;
        var strLength = strPass.length;
        var lchar = val.value.charAt((strLength) - 1);
        var cCode = CalcKeyCode(lchar);
        if (cCode < 48 || cCode > 57) {
            var myNumber = val.value.substring(0, (strLength) - 1);
            val.value = myNumber;
        }
        return false;
    }
    JQ$(jq(tPhoneNumber1)).keyup(function() {
        JQ$.fn.checkNumber(JQ$(this)[0]);
    });
    JQ$(jq(tPhoneNumber1)).keydown(function() {
        JQ$.fn.checkNumber(JQ$(this)[0]);
    });
    // Preventing user from entering special characters
    JQ$.fn.checkNumber = function(val) {
        function CalcKeyCode(aChar) {
            var character = aChar.substring(0, 1);
            var code = aChar.charCodeAt(0);
            return code;
        }
        var strPass = val.value;
        var strLength = strPass.length;
        var lchar = val.value.charAt((strLength) - 1);
        var cCode = CalcKeyCode(lchar);
        if (cCode < 48 || cCode > 57) {
            var myNumber = val.value.substring(0, (strLength) - 1);
            val.value = myNumber;
        }
        return false;
    }
    JQ$(jq(tPhoneNumber2)).keyup(function() {
        JQ$.fn.checkNumber(JQ$(this)[0]);
    });
    JQ$(jq(tPhoneNumber2)).keydown(function() {
        JQ$.fn.checkNumber(JQ$(this)[0]);
    });
    // Preventing user from entering special characters
    JQ$.fn.checkNumber = function(val) {
        function CalcKeyCode(aChar) {
            var character = aChar.substring(0, 1);
            var code = aChar.charCodeAt(0);
            return code;
        }
        var strPass = val.value;
        var strLength = strPass.length;
        var lchar = val.value.charAt((strLength) - 1);
        var cCode = CalcKeyCode(lchar);
        if (cCode < 48 || cCode > 57) {
            var myNumber = val.value.substring(0, (strLength) - 1);
            val.value = myNumber;
        }
        return false;
    }
    JQ$(jq(tCountryMobileCode)).keydown(function(event) {
        IsNumeric(event.keyCode, event);
    });
    JQ$(jq(tCountryPhoneCode)).keydown(function(event) {
        IsNumeric(event.keyCode, event);
    });

    function callpatch() {
        var mobilenumber = JQ$(jq(tMobileNumber)).val();
        var callpatchtime = JQ$(jq(tcurrenttime)).val();
        var allowcallpatching = JQ$(jq(tallowcallpatching)).val();
        var callcenterno = JQ$(jq(tcallcenterno)).val();
        var currentDate = new Date();
        console.log("Mobile No: " + mobilenumber + "Call Patch Time: " + callpatchtime + "Allow Call Patch Time: " + allowcallpatching + "callcenterno: " + callcenterno);
        if (currentDate.getHours() >= 10 && currentDate.getHours() <= 17 && (JQ$(jq(tallowcallpatching)).val() == "true")) {
            var callpatchurl = null;
            callpatchurl = "http://203.122.58.253:8686/Lodha/clicktocall?mno=91" + mobilenumber + "&uid=lodha&pwd=lodha123&bridge=91" + callcenterno + "";
            try {
                JQ$.ajax({
                    type: "POST",
                    url: callpatchurl,
                    dataType: "jsonp"
                });
            } catch (err) {}
        }
        return false;
    }

    function SendvarificationSMS(mobilenumber, varcode) {
        var msgurl = null;
        //msgurl = "http://dev9.lodhagroup.com/OTP/"; 
        msgurl = "https://"+window.location.host+"/OTP/";
        try {
            JQ$.ajax({
                type: "POST",
                url: msgurl,
                cache: false,
                dataType: "jsonp",
                data: {"mobilenumber" : mobilenumber , "varcode" : varcode},
                success: function(data) {
                    alert(data[1]);
                }
            });
        } catch (err) {}
        alert('Please enter the 4-digit verification code sent on your mobile into the highlighted field and submit your enquiry.');
        return true;
    }

    function validateConfCode() {
        if ((JQ$(jq(tallowmobileverification)).val() == "true") && (JQ$(jq(tCountryList)).val() == "India")) {
            if (JQ$(jq(tCountryList)).val() == "India" && (!MobileNumberIndia() || JQ$(jq(tConfCode)).val().length == 0)) {
                return false;
            }
        }
        return true;
    }

    function Invalidconfcode() {
        if ((JQ$(jq(tallowmobileverification)).val() == "true") && (JQ$(jq(tCountryList)).val() == "India")) {
            if (JQ$(jq(tCountryList)).val() == "India" && MobileNumberIndia() && JQ$(jq(tConfCode)).val() != varCode) {
                return false;
            }
        }
        return true;
    }
    JQ$("#GenCodeLink").click(function(e) {
        e.preventDefault();
        if (MobileNumberIndia()) {
            varCode = getRandomNumber();
            JQ$(jq(tConfCode)).val('');
            var mobilenumber = JQ$(jq(tMobileNumber)).val();
            if (validateMobileLandLine() != true) {
                alert(JQ$("#mobile-err").text());
                return false;
            }
            SendvarificationSMS(mobilenumber, varCode);
            JQ$('a.casa_submit_btn').css('display', 'none');
            JQ$('#processing_msg_code').css('display', 'inline-block');
            setTimeout("JQ$('#processing_msg_code').css('display','none');JQ$('a.casa_submit_btn').css('display','inline-block');", 5000);
            JQ$('#verificationdiv input').css('background', '#ffc').focus();
        } else {
            alert(JQ$("#mobile_max").text());
        }
        return false;
    });
    // Form Submission  
    JQ$("#SubmitLeadLink").click(function() {
		if (validateProject() & validateName() & validateName1() & validateEmailID() & validateCompany() & validateEmailIDblank() & validateCountry() & validateCity() & validateMobileLandLine() & MobileNumberStartswithzero() & MobileNumberIndia() /*& validate_landlinephone() & validate_landphone() & validate_stdcode() & validate_landphonestd()*/ & validateCity_Text() & validateCity_Text1() & valid_mobile_no() /*& valid_std_code() & valid_landline_no() & Landline_null_nonindia_() & stdcodeNaN() & landlineNaN() & std_null_nonindia() */ & validateConfCode() & Invalidconfcode()) {
            /** show processing image**/
            //JQ$('a.casa_submit_btn').css('display','none');
            //JQ$('#processing_msg').css('display','block');
            //document.getElementById("retURL").value = "http://www.testlodhagroup.com/supremus/activation/thankyou.php";
            if (JQ$(".ext_country_prefix").val() == 0091) {
                //var phone2 = JQ$(".ext_country_prefix").val();
                var phone5 = JQ$(".ext_std_res_phone").val();
                var phone3 = JQ$(".res_no").val();
                var phone4 = phone5 + phone3;
                JQ$("#phone_con").val(phone4);
            } else {
                var phone2 = JQ$(".ext_country_prefix").val();
                var phone5 = JQ$(".ext_std_res_phone").val();
                var phone3 = JQ$(".res_no").val();
                var phone4 = phone2 + phone5 + phone3;
                JQ$("#phone_con").val(phone4);
            }
            var mob_ext_get = JQ$(".ext_mob").val();
            if (mob_ext_get != 0091) {
                var mob_no_get = JQ$(".mobile_no_get").val();
                var mobile4 = mob_ext_get + mob_no_get;
                JQ$(".mobile_no_fetch").val(mobile4);
                console.log(mobile4);
            } else {
                var mob_no_get = JQ$(".mobile_no_get").val();
                JQ$(".mobile_no_fetch").val(mob_no_get);
            }
            if (JQ$(".country").val() == "India") {
                JQ$(".city_send").val(JQ$("#city_dropdown").val());
            } else if (JQ$(".country").val() == "United States") {
                JQ$(".city_send").val(JQ$(".state_us").val());
            } else {
                JQ$(".city_send").val(JQ$(".city_input").val());
            }
            if (JQ$(".country").val() == "India") {
                callpatch();
            }
            valid = true;
			//getTimespentform();
			/* var now  = "'"+datetime+"'";	
			var then = "'"+onload_datetime+"'";
			var diff = moment.utc(moment(now,"DD-MM-YYYY HH:mm:ss").diff(moment(then,"DD-MM-YYYY HH:mm:ss"))).format("HH:mm:ss");
			JQ$("#Time_Spent_before_Form_Submit__c").val(diff); */
			
			
/*
JQ$.ajax({
	url: "getnowdatetime.php",
	type: "post",
	success: function(now) {
		var then = "'"+onload_datetime+"'";
		var diff = moment.utc(moment(now,"DD-MM-YYYY HH:mm:ss").diff(moment(then,"DD-MM-YYYY HH:mm:ss"))).format("HH:mm:ss");
		//console.log(diff);
		JQ$("#Time_Spent_before_Form_Submit__c").val(diff);
		alert(diff);
	}
}); */
			getTimespentform();//Time_Spent_before_Form_Submit__c
			var width = screen.width;
			var height = screen.height;
			var resolution = width +"*"+height;
			JQ$("#Resolution__c").val(resolution);	

            // GTM Event Track
            JQ$.GtmTrack('Contact Us Form Tracking', 'Completed', 'Submit Button Click', 'Form Submit From Page (' + CURRENT_URL + ')');
			
			JQ$('#form_submit_abc').delay(15000).submit(function() {
                return true;
            });
			
			
        } else {
            if (validateProject() != true) {
                alert(JQ$("#pname-err").text());
                return false;
            }
            if (validateName() != true) { 
                alert(JQ$("#uname-err").text());
				setTimeout(function() { JQ$(".n1").focus();JQ$(".n1").addClass('error_focus'); }, 1);
                return false;
            }
            if (validateName1() != true) {
                alert(JQ$("#uname-err1").text());
				setTimeout(function() { JQ$(".n1").focus();JQ$(".n1").addClass('error_focus'); }, 1);
                return false;
            }
            if (validateEmailID() != true) {
                alert(JQ$("#emailid-err").text());
				setTimeout(function() { JQ$(".e1").focus();JQ$(".e1").addClass('error_focus'); }, 1);
                return false;
            }
            if (validateEmailIDblank() == false) {
                alert(JQ$("#emailid1-err").text());
				setTimeout(function() { JQ$(".e1").focus();JQ$(".e1").addClass('error_focus'); }, 1);
                return false;
            }
            if (validateCompany() != true) {
                alert(j$("#Compname_err").text());
                return false;
            }
            if (validateCountry() != true) {
                alert(JQ$("#country-err").text());
				setTimeout(function() { JQ$(".country").focus().select();JQ$(".country").addClass('error_focus'); }, 1);
                return false;
            }
            if (validateCity() != true) {
                alert(JQ$("#city-err1").text());
				setTimeout(function() { JQ$(".city_dropdown").focus().select().addClass('error_focus');JQ$(".state_us").focus().select().addClass('error_focus');  }, 1);
                return false; 
            }
            if (validateCity_Text() != true) {
                alert(JQ$("#city-err").text());
				setTimeout(function() { JQ$(".city_input").focus(); JQ$(".city_input").addClass('error_focus'); }, 1);
                return false;
            }
            if (validateCity_Text1() != true) {
                alert(JQ$("#city-err2").text());
				setTimeout(function() { JQ$(".city_input").focus(); JQ$(".city_input").addClass('error_focus'); }, 1);
                return false;
            }
            if (validateMobileLandLine() != true) {
                alert(JQ$("#mobile-err").text());
				setTimeout(function() { JQ$(".m2").focus(); JQ$(".m2").addClass('error_focus'); }, 1);
                return false;
            }
            if (MobileNumberStartswithzero() != true) {
                alert(JQ$("#mobile_zero").text());
				setTimeout(function() { JQ$(".m2").focus(); JQ$(".m2").addClass('error_focus'); }, 1);
                return false;
            }
            if (valid_mobile_no() != true) {
                alert(JQ$("#mobile-err1").text());
				setTimeout(function() { JQ$(".m2").focus(); JQ$(".m2").addClass('error_focus'); }, 1);
                return false;
            }
            if (MobileNumberIndia() != true) {
                alert(JQ$("#mobile_max").text());
				setTimeout(function() { JQ$(".m2").focus(); JQ$(".m2").addClass('error_focus'); }, 1);
                return false;
            }
            if (validateConfCode() != true) {
                alert('Please validate your mobile number');
                return false;
            }
            if (Invalidconfcode() != true) {
                alert('Invalid verification code.');
                return false;
            }
            if (validate_landphonestd() != true) {
                alert('Please enter STD Code');
                return false;
            }
            if (validate_stdcode() != true) {
                alert('STD code should begin with 0');
                return false;
            }
            if (valid_std_code() != true) {
                alert('Please enter a valid STD code');
                return false;
            }
            if (validate_landphone() != true) {
                alert('Please enter a Landline number');
                return false;
            }
            if (valid_landline_no() != true) {
                alert('Please enter a valid Landline number');
                return false;
            }
            if (validate_landlinephone() != true) {
                alert('Please enter a valid Landline number');
                return false;
            }
            if (stdcodeNaN() != true) {
                //alert('STD code should not start with 0');
                alert('Please enter STD code without 0');
                return false;
            }
            if (Landline_null_nonindia_() != true) {
                alert('Please enter a Landline number');
                return false;
            }
            if (std_null_nonindia() != true) {
                alert('Please enter a STD Code');
                return false;
            }
            if (landlineNaN() != true) {
                alert('Please enter a valid Landline number');
                return false;
            }
            return false;
        }
    });
});

JQ$("input, select").blur(function(){
	getTimespentform();
});//

function getTimespentform(){
	JQ$.ajax({
		url: "getnowdatetime.php",
		type: "post",
		success: function(now) {
			var then = "'"+onload_datetime+"'";
			var diff = moment.utc(moment(now,"DD-MM-YYYY HH:mm:ss").diff(moment(then,"DD-MM-YYYY HH:mm:ss"))).format("HH:mm:ss");
			JQ$("#Time_Spent_before_Form_Submit__c").val(diff);
			//console.log(JQ$("#Time_Spent_before_Form_Submit__c").val());
		}
	});
}//getTime_Spent_before_Form_Submit__c	

var tMobileNumber = "j_id0:enq_frm:pageblock1:mobile2";
var tPhoneNumber1 = "j_id0:enq_frm:pageblock1:phone2";
var tPhoneNumber2 = "j_id0:enq_frm:pageblock1:phone3";
var tprojectName = "j_id0:enq_frm:pageblock1:projectName";
var tfirstName = "j_id0:enq_frm:pageblock1:firstname";
var temailID = "j_id0:enq_frm:pageblock1:email";
var tCountryList = "j_id0:enq_frm:pageblock1:countrylist";
var tCity = "j_id0:enq_frm:pageblock1:div_city_dropdown";
var tDesignation = "";
var tState = "j_id0:enq_frm:pageblock1:statelist_id";
var tSubmitData = "";
//
var tCityText = "j_id0:enq_frm:pageblock1:div_city";
var tLastName = "";
var tCountryPhoneCode = "j_id0:enq_frm:pageblock1:phone1";
var tCountryMobileCode = "j_id0:enq_frm:pageblock1:mobile1";
var tProjectType = "j_id0:enq_frm:pageblock1:tProjectType";
var tsuccess = "";
var treturl = "http://park.tejashingu.com/thank-you/";
var tConfCode = "j_id0:enq_frm:pageblock1:ConfirmationCode";
var tallowmobileverification = "j_id0:enq_frm:pageblock1:allowmobileverification";
var trecvalue = "j_id0:enq_frm:pageblock1:recvalue";
var tcurrenttime = "j_id0:enq_frm:pageblock1:currenttime";
var tallowcallpatching = "j_id0:enq_frm:pageblock1:allowcallpatching";
var tcallcenterno = "j_id0:enq_frm:pageblock1:callcenterno";
var valid = false;
var tcompanyName = "j_id0:enq_frm:pageblock1:CompanyBlock";
/**
 * Validate Company
 * @return {[type]} [description]
 */
function validateCompany() {
    j$("#Compname_err").hide();
    if (j$(jq(tcompanyName)).val() == '') {
        return false;
    }
    return true;
}
/*
 *       Get Country Code
 */
// populate country codes ;default to India
 
   function getAPICity(country){
     var msgurl  = "https://"+window.location.host+"/city-list/"+country+".php";
        try {
            JQ$.ajax({
                type: "POST",
                url: msgurl,
                cache: false,
                dataType: "json",
				error: function (request, error) {
					console.log(arguments);
					alert(" Can't do because: " + error);
				},
                success: function(data) {
                    var html = "<option value=''>-- Select City --</option>";
                    for(var i=0;i<Object.keys(data).length;i++){
                        if(data[i] == "------------------------------"){ 
                            html += "<option value='' disabled>"+data[i]+"</option>";
                        }else{
                            html += "<option value='"+data[i]+"'>"+data[i]+"</option>";
                        }
                    }
                   JQ$(jq(tCity)).html(html);
                }
            });
        } catch (err) {}
       // alert('Invalid Country');
        return true;
 }
 
 function getUSCity(){
     var msgurl  = "https://"+window.location.host+"/city-list/us.php";
        try {
            JQ$.ajax({
                type: "POST",
                url: msgurl,
                cache: false,
                dataType: "json",
                success: function(data) {
                    var html = "<option value=''>-- Select City --</option>";
                    for(var i=0;i<Object.keys(data).length;i++){
                        if(data[i] == "------------------------------"){
                            html += "<option value='' disabled>"+data[i]+"</option>";
                        }else{
                            html += "<option value='"+data[i]+"'>"+data[i]+"</option>";
                        }
                        
                    }
                   JQ$(jq(tState)).html(html);
                }
            });
        } catch (err) {}
       // alert('Invalid US Country');
        return true;
 }
 
// populate country codes ;default to India
var pgurl_without_parameter = window.location.href.split('?')[0];
var pgurl = pgurl_without_parameter.substr(pgurl_without_parameter.lastIndexOf("/") + 1);
if(pgurl == ""){
getCountryValue();
}
function getCountryValue() {
    //document.getElementById("residence_choice").style.display = "none";
    //document.getElementById("LandlineBlock").style.display = "none";
    var countrycode = "";
    var InitialCountryName = document.getElementById("j_id0:enq_frm:pageblock1:countrylist").value;
    var ParameterCountryName = document.getElementById("j_id0:enq_frm:pageblock1:CompanyName1").value;
    var CheckCode = document.getElementById("j_id0:enq_frm:pageblock1:CheckCode").value;
    if ((InitialCountryName != ParameterCountryName) && CheckCode == '0') {
        var countryname = document.getElementById("j_id0:enq_frm:pageblock1:countrylist").value = "India";
        document.getElementById("j_id0:enq_frm:pageblock1:CheckCode").value = '1';
    } else if ((InitialCountryName == ParameterCountryName) && CheckCode == '0') {
        var countryname = document.getElementById("j_id0:enq_frm:pageblock1:countrylist").value;
        document.getElementById("j_id0:enq_frm:pageblock1:CheckCode").value = '1';
    } else {
        var countryname = document.getElementById("j_id0:enq_frm:pageblock1:countrylist").value;
    }
    if (countryname == "India" && JQ$(jq(tallowmobileverification)).val() == "true") {
        document.getElementById("j_id0:enq_frm:pageblock1:div_city_dropdown").style.display = "inline-block";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").style.display = "none";
        document.getElementById("VerificationBlock").style.display = "inline-block";
        document.getElementById("verificationdiv").style.display = "inline-block";
        document.getElementById("veri_pass").style.display = "inline-block";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").value = "";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").value = "";
        getAPICity("india");
    } else if (countryname == "India" && JQ$(jq(tallowmobileverification)).val() == "false") {
        document.getElementById("j_id0:enq_frm:pageblock1:div_city_dropdown").style.display = "inline-block";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").style.display = "none";
        document.getElementById("VerificationBlock").style.display = "none";
        document.getElementById("verificationdiv").style.display = "none";
        document.getElementById("veri_pass").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").value = "";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").value = "";
        getAPICity("india");
    } else if (countryname == "United States" && JQ$(jq(trecvalue)).val() == "Residential") {
        document.getElementById("j_id0:enq_frm:pageblock1:div_city_dropdown").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").style.display = "inline-block";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").style.display = "none";
        document.getElementById("VerificationBlock").style.display = "none";
        document.getElementById("verificationdiv").style.display = "none";
        document.getElementById("veri_pass").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city_dropdown").value = "";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").value = "";
        getUSCity();
    } 
    
    else if (countryname == "United Kingdom") {
        document.getElementById("j_id0:enq_frm:pageblock1:div_city_dropdown").style.display = "inline-block";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").style.display = "none";
        document.getElementById("VerificationBlock").style.display = "none";
        document.getElementById("verificationdiv").style.display = "none";
        document.getElementById("veri_pass").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").value = "";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").value = "";
        getAPICity("uk");
    }
    else if (countryname == "United Arab Emirates") {
        document.getElementById("j_id0:enq_frm:pageblock1:div_city_dropdown").style.display = "inline-block";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").style.display = "none";
        document.getElementById("VerificationBlock").style.display = "none";
        document.getElementById("verificationdiv").style.display = "none";
        document.getElementById("veri_pass").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").value = "";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").value = "";
        getAPICity("uae");
    }
    else if (countryname == "Saudi Arabia") {
        document.getElementById("j_id0:enq_frm:pageblock1:div_city_dropdown").style.display = "inline-block";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").style.display = "none";
        document.getElementById("VerificationBlock").style.display = "none";
        document.getElementById("verificationdiv").style.display = "none";
        document.getElementById("veri_pass").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").value = "";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").value = "";
        getAPICity("saudi");
    }
    else if (countryname == "Kuwait") {
        document.getElementById("j_id0:enq_frm:pageblock1:div_city_dropdown").style.display = "inline-block";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").style.display = "none";
        document.getElementById("VerificationBlock").style.display = "none";
        document.getElementById("verificationdiv").style.display = "none";
        document.getElementById("veri_pass").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").value = "";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").value = "";
        getAPICity("kuwait");
    }else if (countryname == "Singapore") {
        document.getElementById("j_id0:enq_frm:pageblock1:div_city_dropdown").style.display = "inline-block";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").style.display = "none";
        document.getElementById("VerificationBlock").style.display = "none";
        document.getElementById("verificationdiv").style.display = "none";
        document.getElementById("veri_pass").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").value = "";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").value = "";
        getAPICity("singapore");
    }
    else if (countryname == "Hong Kong") {
        document.getElementById("j_id0:enq_frm:pageblock1:div_city_dropdown").style.display = "inline-block";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").style.display = "none";
        document.getElementById("VerificationBlock").style.display = "none";
        document.getElementById("verificationdiv").style.display = "none";
        document.getElementById("veri_pass").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").value = "";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").value = "";
        getAPICity("hongkong");
    }
    else if (countryname == "China") {
        document.getElementById("j_id0:enq_frm:pageblock1:div_city_dropdown").style.display = "inline-block";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").style.display = "none";
        document.getElementById("VerificationBlock").style.display = "none";
        document.getElementById("verificationdiv").style.display = "none";
        document.getElementById("veri_pass").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").value = "";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").value = "";
        getAPICity("china");
    }
    else {
        document.getElementById("j_id0:enq_frm:pageblock1:div_city_dropdown").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city").style.display = "inline-block";
        document.getElementById("VerificationBlock").style.display = "none";
        document.getElementById("verificationdiv").style.display = "none";
        document.getElementById("veri_pass").style.display = "none";
        document.getElementById("j_id0:enq_frm:pageblock1:statelist_id").value = "";
        document.getElementById("j_id0:enq_frm:pageblock1:div_city_dropdown").value = "";
    }
     if (countryname == "United States") countrycode = "1";
    if (countryname == "Albania") countrycode = "355";
    if (countryname == "Algeria") countrycode = "213";
    if (countryname == "Angola") countrycode = "244";
    if (countryname == "Argentina") countrycode = "54";
    if (countryname == "Armenia") countrycode = "374";
    if (countryname == "Australia") countrycode = "61";
    if (countryname == "Austria") countrycode = "43";
    if (countryname == "Azerbaijan") countrycode = "994";
    if (countryname == "Bahamas") countrycode = "1242";
    if (countryname == "Bahrain") countrycode = "973";
    if (countryname == "Bangladesh") countrycode = "880";
    if (countryname == "Belarus") countrycode = "375";
    if (countryname == "Belgium") countrycode = "32";
    if (countryname == "Benin") countrycode = "229";
    if (countryname == "Bermuda") countrycode = "1441";
    if (countryname == "Bolivia") countrycode = "591";
    if (countryname == "Bosnia and Herzegovina") countrycode = "387";
    if (countryname == "Botswana") countrycode = "267";
    if (countryname == "Brazil") countrycode = "55";
    if (countryname == "Bulgaria") countrycode = "359";
    if (countryname == "Canada") countrycode = "1";
    if (countryname == "Chile") countrycode = "56";
    if (countryname == "China") countrycode = "86";
    if (countryname == "Colombia") countrycode = "57";
    if (countryname == "Cook Islands") countrycode = "682";
    if (countryname == "Costa Rica") countrycode = "506";
    if (countryname == "Croatia") countrycode = "385";
    if (countryname == "Cyprus") countrycode = "357";
    if (countryname == "Czech Republic") countrycode = "420";
    if (countryname == "Denmark") countrycode = "45";
    if (countryname == "Dominican Republic") countrycode = "1809";
    if (countryname == "Ecuador") countrycode = "593";
    if (countryname == "Egypt") countrycode = "20";
    if (countryname == "El Salvador") countrycode = "503";
    if (countryname == "Equatorial Guinea") countrycode = "240";
    if (countryname == "Estonia") countrycode = "372";
    if (countryname == "Ethiopia") countrycode = "251";
    if (countryname == "Faroe Islands") countrycode = "298";
    if (countryname == "Finland") countrycode = "358";
    if (countryname == "France") countrycode = "33";
    if (countryname == "French Polynesia") countrycode = "689";
    if (countryname == "Gabon") countrycode = "241";
    if (countryname == "Gambia") countrycode = "220";
    if (countryname == "Georgia") countrycode = "995";
    if (countryname == "Germany") countrycode = "49";
    if (countryname == "Ghana") countrycode = "233";
    if (countryname == "Gibraltar") countrycode = "350";
    if (countryname == "Greece") countrycode = "30";
    if (countryname == "Greenland") countrycode = "299";
    if (countryname == "Guatemala") countrycode = "502";
    if (countryname == "Honduras") countrycode = "504";
    if (countryname == "Hong Kong") countrycode = "852";
    if (countryname == "Hungary") countrycode = "36";
    if (countryname == "Iceland") countrycode = "354";
    if (countryname == "India") countrycode = "91";
    if (countryname == "Indonesia") countrycode = "62";
    if (countryname == "Iran") countrycode = "98";
    if (countryname == "Iraq") countrycode = "964";
    if (countryname == "Ireland") countrycode = "353";
    if (countryname == "Israel") countrycode = "972";
    if (countryname == "Italy") countrycode = "39";
    if (countryname == "Japan") countrycode = "81";
    if (countryname == "Jordan") countrycode = "962";
    if (countryname == "Kazakhstan") countrycode = "7";
    if (countryname == "Kenya") countrycode = "254";
    if (countryname == "South Korea") countrycode = "82";
    if (countryname == "North Korea") countrycode = "850";
    if (countryname == "Kuwait") countrycode = "965";
    if (countryname == "Kyrgyzstan") countrycode = "996";
    if (countryname == "Latvia") countrycode = "371";
    if (countryname == "Lebanon") countrycode = "961";
    if (countryname == "Liechtenstein") countrycode = "423";
    if (countryname == "Lithuania") countrycode = "370";
    if (countryname == "Luxembourg") countrycode = "352";
    if (countryname == "Macedonia") countrycode = "389";
    if (countryname == "Madagascar") countrycode = "261";
    if (countryname == "Malaysia") countrycode = "60";
    if (countryname == "Malta") countrycode = "353";
    if (countryname == "Mauritius") countrycode = "230";
    if (countryname == "Mexico") countrycode = "52";
    if (countryname == "Moldova") countrycode = "373";
    if (countryname == "Morocco") countrycode = "212";
    if (countryname == "Namibia") countrycode = "264";
    if (countryname == "Nepal") countrycode = "977";
    if (countryname == "Netherlands") countrycode = "31";
    if (countryname == "Netherlands Antilles") countrycode = "599";
    if (countryname == "New Zealand") countrycode = "64";
    if (countryname == "Nicaragua") countrycode = "505";
    if (countryname == "Nigeria") countrycode = "234";
    if (countryname == "Norway") countrycode = "47";
    if (countryname == "Pakistan") countrycode = "92";
    if (countryname == "Panama") countrycode = "507";
    if (countryname == "Peru") countrycode = "51";
    if (countryname == "Philippines") countrycode = "63";
    if (countryname == "Poland") countrycode = "48";
    if (countryname == "Portugal") countrycode = "351";
    if (countryname == "Qatar") countrycode = "974";
    if (countryname == "Romania") countrycode = "40";
    if (countryname == "Russia") countrycode = "7";
    if (countryname == "Saudi Arabia") countrycode = "966";
    if (countryname == "Saint Helena") countrycode = "290";
    if (countryname == "Saint Pierre and Miquelon") countrycode = "508";
    if (countryname == "Saint Vincent and the Grenadines") countrycode = "1784";
    if (countryname == "Singapore") countrycode = "65";
    if (countryname == "Slovak Republic") countrycode = "421";
    if (countryname == "Slovenia") countrycode = "386";
    if (countryname == "South Africa") countrycode = "27";
    if (countryname == "Spain") countrycode = "34";
    if (countryname == "Sri Lanka") countrycode = "94";
    if (countryname == "Sultanate of Oman") countrycode = "968";
    if (countryname == "Sweden") countrycode = "46";
    if (countryname == "Switzerland") countrycode = "41";
    if (countryname == "Syria") countrycode = "963";
    if (countryname == "Taiwan") countrycode = "886";
    if (countryname == "Tanzania") countrycode = "255";
    if (countryname == "Thailand") countrycode = "66";
    if (countryname == "Timor-Leste") countrycode = "670";
    if (countryname == "Togo") countrycode = "228";
    if (countryname == "Trinidad and Tobago") countrycode = "1868";
    if (countryname == "Tunisia") countrycode = "216";
    if (countryname == "Turkey") countrycode = "90";
    if (countryname == "Uganda") countrycode = "256";
    if (countryname == "Ukraine") countrycode = "380";
    if (countryname == "United Arab Emirates") countrycode = "971";
    if (countryname == "United Kingdom") countrycode = "44";
    if (countryname == "Uruguay") countrycode = "598";
    if (countryname == "Uzbekistan") countrycode = "998";
    if (countryname == "Venezuela") countrycode = "58";
    if (countryname == "Viet Nam") countrycode = "84";
    if (countryname == "Yemen") countrycode = "967";
    if (countryname == "Yugoslavia") countrycode = "967";
    if (countryname == "Zimbabwe") countrycode = "263";
    if (countryname == "American Samoa") countrycode = "1684";
    if (countryname == "Andorra") countrycode = "376";
    if (countryname == "Anguilla") countrycode = "1264";
    if (countryname == "Antarctica") countrycode = "672";
    if (countryname == "Antigua and Barbuda") countrycode = "1268";
    if (countryname == "Aruba") countrycode = "297";
    if (countryname == "Barbados") countrycode = "1246";
    if (countryname == "Belize") countrycode = "501";
    if (countryname == "Bhutan") countrycode = "975";
    if (countryname == "Bouvet Island") countrycode = "47";
    if (countryname == "British Indian Ocean Territory") countrycode = "1284";
    if (countryname == "British Virgin Islands") countrycode = "1284";
    if (countryname == "Brunei") countrycode = "673";
    if (countryname == "Burkina Faso") countrycode = "226";
    if (countryname == "Burundi") countrycode = "257";
    if (countryname == "Cambodia") countrycode = "855";
    if (countryname == "Cameroon") countrycode = "237";
    if (countryname == "Cape Verde") countrycode = "238";
    if (countryname == "Cayman Islands") countrycode = "1345";
    if (countryname == "Central African Republic") countrycode = "236";
    if (countryname == "Chad") countrycode = "235";
    if (countryname == "Christmas Island") countrycode = "61";
    if (countryname == "Cocos Islands") countrycode = "61";
    if (countryname == "Comoros") countrycode = "269";
    if (countryname == "Congo") countrycode = "242";
    if (countryname == "Cuba") countrycode = "53";
    if (countryname == "Democratic Republic of the Congo") countrycode = "243";
    if (countryname == "Djibouti") countrycode = "253";
    if (countryname == "Dominica") countrycode = "1767";
    if (countryname == "East Timor") countrycode = "670";
    if (countryname == "Eritrea") countrycode = "291";
    if (countryname == "ElSalvador") countrycode = "503";
    if (countryname == "Falkland Islands") countrycode = "500";
    if (countryname == "Fiji") countrycode = "679";
    if (countryname == "French Guiana") countrycode = "594";
    if (countryname == "French Southern Territories") countrycode = "689";
    if (countryname == "Grenada") countrycode = "1473";
    if (countryname == "Guadeloupe") countrycode = "590";
    if (countryname == "Guam") countrycode = "1671";
    if (countryname == "Guinea") countrycode = "224";
    if (countryname == "Guinea-Bissau") countrycode = "245";
    if (countryname == "Guernsey") countrycode = "441481";
    if (countryname == "Guyana") countrycode = "592";
    if (countryname == "Haiti") countrycode = "509";
    if (countryname == "Heard and McDonald Islands") countrycode = "509";
    if (countryname == "Afghanistan") countrycode = "93";
    if (countryname == "Ivory Coast") countrycode = "225";
    if (countryname == "Isle Of Man") countrycode = "441624";
    if (countryname == "Jamaica") countrycode = "1876";
    if (countryname == "Jersey") countrycode = "441534";
    if (countryname == "Kiribati") countrycode = "686";
    if (countryname == "Kosovo") countrycode = "383";
    if (countryname == "Laos") countrycode = "856";
    if (countryname == "Lesotho") countrycode = "266";
    if (countryname == "Liberia") countrycode = "231";
    if (countryname == "Libya") countrycode = "218";
    if (countryname == "Macau") countrycode = "853";
    if (countryname == "Malawi") countrycode = "265";
    if (countryname == "Maldives") countrycode = "960";
    if (countryname == "Mali") countrycode = "223";
    if (countryname == "Marshall Islands") countrycode = "692";
    if (countryname == "Martinique") countrycode = "596";
    if (countryname == "Mauritania") countrycode = "222";
    if (countryname == "Mayotte") countrycode = "262";
    if (countryname == "Micronesia") countrycode = "691";
    if (countryname == "Monaco") countrycode = "377";
    if (countryname == "Mongolia") countrycode = "976";
    if (countryname == "Montserrat") countrycode = "1664";
    if (countryname == "Montenegro") countrycode = "382";
    if (countryname == "Mozambique") countrycode = "258";
    if (countryname == "Myanmar") countrycode = "95";
    if (countryname == "Nauru") countrycode = "674";
    if (countryname == "New Caledonia") countrycode = "687";
    if (countryname == "Niger") countrycode = "227";
    if (countryname == "Niue") countrycode = "683";
    if (countryname == "Norfolk Island") countrycode = "6723";
    if (countryname == "Northern Mariana Islands") countrycode = "1670";
    if (countryname == "Oman") countrycode = "968";
    if (countryname == "Palau") countrycode = "680";
    if (countryname == "Papua New Guinea") countrycode = "675";
    if (countryname == "Paraguay") countrycode = "595";
    if (countryname == "Pitcairn Islands") countrycode = "64";
    if (countryname == "Puerto Rico") countrycode = "1939";
    if (countryname == "Republic of the Congo") countrycode = "242";
    if (countryname == "Reunion") countrycode = "262";
    if (countryname == "Rwanda") countrycode = "250";
    if (countryname == "S. Georgia and S. Sandwich Isls.") countrycode = "7";
    if (countryname == "Saint Kitts and Nevis") countrycode = "1869";
    if (countryname == "Saint Lucia") countrycode = "1758";
    if (countryname == "Saint Vincent and The Grenadines") countrycode = "1";
    if (countryname == "Samoa") countrycode = "685";
    if (countryname == "San Marino") countrycode = "378";
    if (countryname == "Sao Tome and Principe") countrycode = "239";
    if (countryname == "Senegal") countrycode = "221";
    if (countryname == "Serbia") countrycode = "381";
    if (countryname == "Seychelles") countrycode = "248";
    if (countryname == "Solomon Islands") countrycode = "677";
    if (countryname == "Sierra Leone") countrycode = "232";
    if (countryname == "Slovakia") countrycode = "421";
    if (countryname == "Somalia") countrycode = "252";
    if (countryname == "St. Helena") countrycode = "290";
    if (countryname == "St. Pierre and Miquelon") countrycode = "508";
    if (countryname == "Sudan") countrycode = "249";
    if (countryname == "Suriname") countrycode = "597";
    if (countryname == "Svalbard and Jan Mayen Islands") countrycode = "597";
    if (countryname == "Swaziland") countrycode = "268";
    if (countryname == "Tajikistan") countrycode = "992";
    if (countryname == "Tokelau") countrycode = "690";
    if (countryname == "Tonga") countrycode = "676";
    if (countryname == "Turkmenistan") countrycode = "993";
    if (countryname == "Turks and Caicos Islands") countrycode = "1649";
    if (countryname == "Tuvalu") countrycode = "688";
    if (countryname == "Vanuatu") countrycode = "678";
    if (countryname == "Vatican City") countrycode = "39";
    if (countryname == "Virgin Islands") countrycode = "1";
    if (countryname == "Wallis and Futuna Islands") countrycode = "681";
    if (countryname == "Western Sahara") countrycode = "212";
    if (countryname == "Zaire") countrycode = "243";
    if (countryname == "Zambia") countrycode = "260";
    document.getElementById("j_id0:enq_frm:pageblock1:mobile1").value = countrycode;
    document.getElementById("j_id0:enq_frm:pageblock1:phone1").value = countrycode;
     document.getElementById("c_code").value = "+"+countrycode;
}

function getprojectid() {
    var projids = JQ$(jq(tprojectName)).val()
    var meridian = SITE_URL + "lodha-meridian/" + THANK_YOU;
    var bellezza = SITE_URL + "lodha-bellezza/" + THANK_YOU;
    var paradiso = SITE_URL + "casa-paradiso/" + THANK_YOU;
    document.getElementById("projid").value = projids;
    if (projids == "a09D000000KfNvM") {
        document.getElementById("retURL").value = meridian;
    } else if (projids == "a09D000000KD1Po") {
        document.getElementById("retURL").value = bellezza;
    } else {
        document.getElementById("retURL").value = paradiso;
    }
}
var href = window.location.pathname;
var projname = href.substr(href.lastIndexOf('/') + 1);
var urlHashProject = window.location.hash;
urlHashProject = urlHashProject.replace('#', '');
if (urlHashProject == "lodha-meridian") {
    JQ$(function() {
        var temp = "a09D000000KfNvM";
        var mySelect = document.getElementById('j_id0:enq_frm:pageblock1:projectName');
        for (var i, j = 0; i = mySelect.options[j]; j++) {
            if (i.value == temp) {
                mySelect.selectedIndex = j;
                break;
            }
        }
    });
    var projids = JQ$(jq(tprojectName)).val()
    document.getElementById("projid").value = "a09D000000KfNvM";
    document.getElementById("retURL").value = SITE_URL + "lodha-meridian/" + THANK_YOU;
} else if (urlHashProject == "lodha-bellezza") {
    JQ$(function() {
        var temp = "a09D000000KD1Po";
        var mySelect = document.getElementById('j_id0:enq_frm:pageblock1:projectName');
        for (var i, j = 0; i = mySelect.options[j]; j++) {
            if (i.value == temp) {
                mySelect.selectedIndex = j;
                break;
            }
        }
    });
    var projids = JQ$(jq(tprojectName)).val()
    document.getElementById("projid").value = "a09D000000KD1Po";
    document.getElementById("retURL").value = SITE_URL + "lodha-bellezza/" + THANK_YOU;
} else if (urlHashProject == "casa-paradiso") {
    JQ$(function() {
        var temp = "a092000000BaNrp";
        var mySelect = document.getElementById('j_id0:enq_frm:pageblock1:projectName');
        for (var i, j = 0; i = mySelect.options[j]; j++) {
            if (i.value == temp) {
                mySelect.selectedIndex = j;
                break;
            }
        }
    });
    var projids = JQ$(jq(tprojectName)).val()
    document.getElementById("projid").value = "a092000000BaNrp";
    document.getElementById("retURL").value = SITE_URL + "casa-paradiso/" + THANK_YOU;
}


JQ$(document).ready(function() {
    menuActivePageWise();

    // Stickey Header
    JQ$(window).scroll(function () {
        var headerHeigt = JQ$('.headerTop').height();
        if(JQ$(window).scrollTop() > headerHeigt && !(JQ$('.headerTop').hasClass('header-fixed'))){
            JQ$('.headerTop').addClass('header-fixed');
        } else if (JQ$(window).scrollTop() == 0){
            JQ$('.headerTop').removeClass('header-fixed');
        }
    });

    // Set Contact Menu Width
    if(JQ$(".home").length){
        //contactMenuWidth();
    }

    // Toggle Menu
    JQ$('.toggleMenu a.mobielNav').click(function(e) {
        e.preventDefault();
        JQ$(this).toggleClass('active');
        JQ$('.topMenu').toggleClass('active');
    });
    JQ$(document).on('click','a.contactUs-mobile',function(e){
        if(JQ$(".home").length){
            e.preventDefault();
        }
        formTop();
    });
/* 
    //Plans
    JQ$('.plans .bxslider').bxSlider({
        pagerCustom: '#bx-pager',
        controls:false,
    });

    //Partners
    JQ$('.partners').addClass('partDesk');
    JQ$('.partners .bxslider').bxSlider({
        mode: 'vertical',
        pagerCustom: '#bx-pager',
        controls:false,
        infiniteLoop:false
    });
    JQ$('.selectOption a').on('click',function(){
        JQ$('.partners #bx-pager').stop().slideToggle();
    });
    

    // Plans Popup Overlay
    JQ$('.plans .SliderImg a img').click(function(e){
        e.preventDefault();
        var bigImgPath = JQ$(this).data('overlay');
	 JQ$('.bigImg').attr('src',bigImgPath)
        JQ$('#firstOverlayWrapper').show();
    });
    JQ$("#firstOverlay, .imageBox #closeBtn").click(function(e){
        e.preventDefault();
        JQ$("#firstOverlayWrapper").hide();
    });

    // Plans Popup Overlay for Mobile
    JQ$('.SliderImg .bxslider li a img').click(function(e) {
		//alert();
        e.preventDefault();
        var bigImgPath = JQ$(this).data('overlay');
        JQ$('.bigImg').attr('src', bigImgPath);
        JQ$('#firstOverlayWrapper').show();
		 
    });
	 */
    JQ$("#firstOverlay, .imageBox #closeBtn").click(function(e) {
        e.preventDefault();
        JQ$("#firstOverlayWrapper").hide();
    });

    // Residency Popup Overlay
    JQ$('.residencesList li a').on('click touchend', function(e){
        e.preventDefault();
        var bigImgPath = JQ$(this).find('img.resiImg').data('overlay');
        JQ$('.bigImg').attr('src',bigImgPath)
        JQ$('#firstOverlayWrapper').show();
    });
    JQ$("#firstOverlay, .imageBox #closeBtn").click(function(e){
        e.preventDefault();
        JQ$("#firstOverlayWrapper").hide();
    });

    /* // Set the slider container hiehgt
    var winWidth = JQ$(window).width();               
    if(winWidth > 767) {
        // Verticle Carousel
        var sliderEle = JQ$('.mainContainer').find('.verticalSlider');
        var verticalSlider = sliderEle.bxSlider({
          mode: 'vertical',
          pager:false,
          infiniteLoop:false,
          hideControlOnEnd:true,
          adaptiveHeight:true
        });

        sliderEle.mousewheel(function(event, delta, deltaX, deltaY) {
            if (delta > 0) {
            verticalSlider.goToPrevSlide();
            }
            if (deltaY < 0){
            verticalSlider.goToNextSlide();
            }
            event.stopPropagation();
            event.preventDefault();
        });
        // End

        // Set Container height on Overview Page
        var contentItem = JQ$('.verticalSlider').find('.relContent');
        var itemHeight = JQ$('.verticalSlider').find('.imgContent').find('img').height();
        contentItem.height(itemHeight);
    }

    // Residences Page Slider
    var residencesSlider = JQ$('.mainContainer').find('.residencesList');
    if(winWidth < 767) {            
        residencesSlider.bxSlider({              
          pager:false,
          infiniteLoop:false,
          hideControlOnEnd:true,
          responsive:true
        });
    } 

});

// On window resize
JQ$(window).resize(function(){
    var winWidth = JQ$(window).width();               
    if(winWidth > 767) {
        // Verticle Carousel
        var sliderEle = JQ$('.mainContainer').find('.verticalSlider');
        var verticalSlider = sliderEle.bxSlider({
          mode: 'vertical',
          pager:false,
          infiniteLoop:false,
          hideControlOnEnd:true,
          adaptiveHeight:true
        });

        sliderEle.mousewheel(function(event, delta, deltaX, deltaY) {
            if (delta > 0) {
            verticalSlider.goToPrevSlide();
            }
            if (deltaY < 0){
            verticalSlider.goToNextSlide();
            }
            event.stopPropagation();
            event.preventDefault();
        });
        // End

        // Set Container height on Overview Page
        var contentItem = JQ$('.verticalSlider').find('.relContent');
        var itemHeight = JQ$('.verticalSlider').find('.imgContent').find('img').height();
        contentItem.height(itemHeight);
    }

    // Residences Page Slider
    var residencesSlider = JQ$('.mainContainer').find('.residencesList');
    if(winWidth < 767) {            
        residencesSlider.bxSlider({              
          pager:false,
          infiniteLoop:false,
          hideControlOnEnd:true,
          responsive:true
        });
    } 
}).resize();


if (JQ$(window).width() <= 768) {
    partDropClickHide();
}

JQ$(window).resize(function() {
    if(JQ$(".home").length){
        contactMenuWidth();
    }

    // For Partner Page
    if (JQ$(window).width() > 768) {
        JQ$('.partners').addClass('partDesk');
       
    }else{
        JQ$('.partners').removeClass('partDesk');
        partDropClickHide();
    }
});
 */
 
// Active Menu on click 
function menuActivePageWise(){
    var pgurl = window.location.href.substr(window.location.href.lastIndexOf("/") + 1);
    JQ$("ul.nav a").each(function() {
        if (JQ$(this).attr("href") == pgurl || JQ$(this).attr("href") == ''){
            JQ$(this).addClass("active");
        }
    });
}

function formTop(){
    var headerHeight = JQ$('.headerTop').height();
    var offsetTop = JQ$('.formWrapper').offset().top - headerHeight;
   
    if(!JQ$('.headerTop').hasClass('header-fixed')){
        JQ$('body,html').animate({scrollTop:offsetTop-headerHeight});
    }else{
        JQ$('body,html').animate({scrollTop:offsetTop});
    }
}   
/* 
function contactMenuWidth(){
    var formWht = JQ$(".formWrapper").width();
    JQ$("ul.nav li.contactUs a").width(formWht - 40);
} */

function MM_openBrWindow(url, title, w, h) {
    var left = (screen.width / 2) - (w / 2);
    var top = (screen.height / 2) - (h / 2);
    return window.open(url, title, 'toolbar=no, location=no, directories=no, status=no, menubar=no, scrollbars=yes, resizable=yes, copyhistory=no, width=' + w + ', height=' + h + ', top=' + top + ', left=' + left);
}    

function partDropClickHide(){
    JQ$('.partners #bx-pager a').on('click',function(){
        var partNav = JQ$(this).text();
        JQ$('.partners .selectOption a span').text(partNav);
        JQ$(this).parent().stop().slideUp('fast');
    });
}

JQ$("#mapoverlay").click(function(e){
	JQ$("#firstOverlayWrapper").show();
	JQ$("#map_iframe").attr("src","map.php");
	
});

/* Closing Pop Up on Esc Key */
JQ$(document).keyup(function(e) {
    if (e.keyCode == 27) { // escape key maps to keycode `27`
        JQ$("#firstOverlayWrapper").hide();
    }
	if (e.keyCode == 40 || e.keyCode == 34) { //Down Button Click
		JQ$(".bx-next").click();
    }
	if (e.keyCode == 38 || e.keyCode == 33) { // Up Button Click
	
		JQ$(".bx-prev").click();
    }
});

JQ$("#bookvisit").click(function(e){
	JQ$("#firstOverlayWrapper").show();
	JQ$("#book").attr("src","xpress.php");
});

JQ$("input").blur(function(e) {
    JQ$(this).removeClass("error_focus");
});

JQ$(".country,.city_dropdown,.state_us").blur(function(e) {
    JQ$(this).removeClass("error_focus");
});
});