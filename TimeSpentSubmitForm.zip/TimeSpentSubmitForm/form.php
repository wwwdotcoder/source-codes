<form method="post" action="https://webto.salesforce.com/servlet/servlet.WebToLead" id="form_submit_abc">
    <!-- Project ID -->
    <div class="flt_left casa_contact_box">
        <div class="alignBox">
        <ul>
            <li class="mandFields">all fields mandatory</li>
            <!-- <li>
                <label>Project</label>
                <select id="j_id0:enq_frm:pageblock1:projectName" name="j_id0:enq_frm:pageblock1:projectName" size="1" onchange="A4J.AJAX.Submit('j_id0:enq_frm',event,{'oncomplete':function(request,event,data){getCountryValue();},'similarityGroupingId':'j_id0:enq_frm:pageblock1:j_id10','parameters':{'j_id0:enq_frm:pageblock1:j_id10':'j_id0:enq_frm:pageblock1:j_id10'} } )">
                <select id="j_id0:enq_frm:pageblock1:projectName" name="j_id0:enq_frm:pageblock1:projectName" size="1" onChange="getprojectid();" class="alignright">
                    <option value="None" selected="selected">-- Select Project --</option>
                    <option value="a09D000000KfNvM">Lodha Meridian</option>
                    <option value="a09D000000KD1Po">Lodha Bellezza</option>
                    <option value="a092000000BaNrp">CASA Paradiso</option>
                </select>
                <span class="err-msg" id="pname-err">Please select a Project</span>
            </li> -->
            <li>
                <label for="last_name" class="name">Name </label>
                <input id="j_id0:enq_frm:pageblock1:firstname" maxlength="80" name="last_name" size="22" type="text" class="n1 alignright" />
                <span class="err-msg" id="uname-err">Enter your name</span>
                <span class="err-msg" id="uname-err1">Please enter a valid name</span>
            </li>
            <li>
                <label for="email" class="email">E-mail</label>
                <input id="j_id0:enq_frm:pageblock1:email" maxlength="80" name="email" size="22" type="text" class="e1 alignright" />
                <span class="err-msg" id="emailid-err">Email cannot be blank</span>
                <span class="err-msg" id="emailid1-err">Please enter valid Email Id</span>
            </li>
            <!--<li>
                <label>Company</label>                
                <input type="text" name="j_id0:enq_frm:pageblock1:CompanyBlock" id="j_id0:enq_frm:pageblock1:CompanyBlock" class="e1 alignright">
                <span id="Compname_err" class="err-msg">Please enter a Company</span>
            </li>-->
            <li>
                <label for="country" class="country1">Country</label>
                <select id="j_id0:enq_frm:pageblock1:countrylist" name="00N20000001SJmA" title="Country(R)" class="country c1 alignright" onchange="return getCountryValue()">
                    <option value="" selected="selected">-- Select Country --</option>
			<option value="India" selected="selected">India</option>
					<option value="United States">United States</option>		
					<option value="United Kingdom">United Kingdom</option>
					<option value="United Arab Emirates">United Arab Emirates</option>
					<option value="Saudi Arabia">Saudi Arabia</option>
					<option value="Qatar">Qatar</option>
					<option value="Oman">Oman</option>
					<option value="Kuwait">Kuwait</option>
					<option value="Bahrain">Bahrain</option>
					<option value="None" disabled>--------</option>
                    <option value="Afghanistan">Afghanistan</option>
                    <option value="Albania">Albania</option>
                    <option value="Algeria">Algeria</option>
                    <option value="American Samoa">American Samoa</option>
                    <option value="Andorra">Andorra</option>
                    <option value="Angola">Angola</option>
                    <option value="Anguilla">Anguilla</option>
                    <option value="Antarctica">Antarctica</option>
                    <option value="Antigua and Barbuda">Antigua and Barbuda</option>
                    <option value="Arctic Ocean">Arctic Ocean</option>
                    <option value="Argentina">Argentina</option>
                    <option value="Armenia">Armenia</option>
                    <option value="Aruba">Aruba</option>
                    <option value="Ashmore and Cartier Islands">Ashmore and Cartier Islands</option>
                    <option value="Atlantic Ocean">Atlantic Ocean</option>
                    <option value="Australia">Australia</option>
                    <option value="Austria">Austria</option>
                    <option value="Azerbaijan">Azerbaijan</option>
                    <option value="Bahamas">Bahamas</option>
                    <option value="Baker Island">Baker Island</option>
                    <option value="Bangladesh">Bangladesh</option>
                    <option value="Barbados">Barbados</option>
                    <option value="Bassasda India">Bassasda India</option>
                    <option value="Belarus">Belarus</option>
                    <option value="Belgium">Belgium</option>
                    <option value="Belize">Belize</option>
                    <option value="Benin">Benin</option>
                    <option value="Bermuda">Bermuda</option>
                    <option value="Bhutan">Bhutan</option>
                    <option value="Bolivia">Bolivia</option>
                    <option value="Bosnia and Herzegovina">Bosnia and Herzegovina</option>
                    <option value="Botswana">Botswana</option>
                    <option value="Bouvet Island">Bouvet Island</option>
                    <option value="Brazil">Brazil</option>
                    <option value="British Virgin Islands">British Virgin Islands</option>
                    <option value="Brunei">Brunei</option>
                    <option value="Bulgaria">Bulgaria</option>
                    <option value="Burkina Faso">Burkina Faso</option>
                    <option value="Burundi">Burundi</option>
                    <option value="Cambodia">Cambodia</option>
                    <option value="Cameroon">Cameroon</option>
                    <option value="Canada">Canada</option>
                    <option value="Cape Verde">Cape Verde</option>
                    <option value="Cayman Islands">Cayman Islands</option>
                    <option value="Central African Republic">Central African Republic</option>
                    <option value="Chad">Chad</option>
                    <option value="Chile">Chile</option>
                    <option value="China">China</option>
                    <option value="Christmas Island">Christmas Island</option>
                    <option value="Clipperton Island">Clipperton Island</option>
                    <option value="Cocos Islands">Cocos Islands</option>
                    <option value="Colombia">Colombia</option>
                    <option value="Comoros">Comoros</option>
                    <option value="Cook Islands">Cook Islands</option>
                    <option value="Coral Sea Islands">Coral Sea Islands</option>
                    <option value="Costa Rica">Costa Rica</option>
                    <option value="Cote d&#39;Ivoire">Cote d&#39;Ivoire</option>
                    <option value="Croatia">Croatia</option>
                    <option value="Cuba">Cuba</option>
                    <option value="Cyprus">Cyprus</option>
                    <option value="Czech Republic">Czech Republic</option>
                    <option value="Democratic Republic of the Congo">Democratic Republic of the Congo</option>
                    <option value="Denmark">Denmark</option>
                    <option value="Djibouti">Djibouti</option>
                    <option value="Dominica">Dominica</option>
                    <option value="Dominican Republic">Dominican Republic</option>
                    <option value="East Timor">East Timor</option>
                    <option value="Ecuador">Ecuador</option>
                    <option value="Egypt">Egypt</option>
                    <option value="ElSalvador">ElSalvador</option>
                    <option value="Equatorial Guinea">Equatorial Guinea</option>
                    <option value="Eritrea">Eritrea</option>
                    <option value="Estonia">Estonia</option>
                    <option value="Ethiopia">Ethiopia</option>
                    <option value="Europa Island">Europa Island</option>
                    <option value="Falk land Islands Islas Malvinas">Falk land Islands Islas Malvinas</option>
                    <option value="Faroe Islands">Faroe Islands</option>
                    <option value="Fiji">Fiji</option>
                    <option value="Finland">Finland</option>
                    <option value="France">France</option>
                    <option value="French Guiana">French Guiana</option>
                    <option value="French Polynesia">French Polynesia</option>
                    <option value="French Southern and Antarctic Lands">French Southern and Antarctic Lands</option>
                    <option value="Gabon">Gabon</option>
                    <option value="Gambia">Gambia</option>
                    <option value="GazaStrip">GazaStrip</option>
                    <option value="Georgia">Georgia</option>
                    <option value="Germany">Germany</option>
                    <option value="Ghana">Ghana</option>
                    <option value="Gibraltar">Gibraltar</option>
                    <option value="Glorioso Islands">Glorioso Islands</option>
                    <option value="Greece">Greece</option>
                    <option value="Greenland">Greenland</option>
                    <option value="Grenada">Grenada</option>
                    <option value="Guadeloupe">Guadeloupe</option>
                    <option value="Guam">Guam</option>
                    <option value="Guatemala">Guatemala</option>
                    <option value="Guernsey">Guernsey</option>
                    <option value="Guinea">Guinea</option>
                    <option value="Guinea-Bissau">Guinea-Bissau</option>
                    <option value="Guyana">Guyana</option>
                    <option value="Haiti">Haiti</option>
                    <option value="Heard Island and Mc Donald Islands">Heard Island and Mc Donald Islands</option>
                    <option value="Honduras">Honduras</option>
                    <option value="Hong Kong">Hong Kong</option>
                    <option value="Howland Island">Howland Island</option>
                    <option value="Hungary">Hungary</option>
                    <option value="Iceland">Iceland</option>
                    <option value="Indian Ocean">Indian Ocean</option>
                    <option value="Indonesia">Indonesia</option>
                    <option value="Iran">Iran</option>
                    <option value="Iraq">Iraq</option>
                    <option value="Ireland">Ireland</option>
                    <option value="Isle Of Man">Isle Of Man</option>
                    <option value="Israel">Israel</option>
                    <option value="Italy">Italy</option>
                    <option value="Jamaica">Jamaica</option>
                    <option value="Jan Mayen">Jan Mayen</option>
                    <option value="Japan">Japan</option>
                    <option value="Jarvis Island">Jarvis Island</option>
                    <option value="Jersey">Jersey</option>
                    <option value="Johnston Atoll">Johnston Atoll</option>
                    <option value="Jordan">Jordan</option>
                    <option value="Juande Nova Island">Juande Nova Island</option>
                    <option value="Kazakhstan">Kazakhstan</option>
                    <option value="Kenya">Kenya</option>
                    <option value="Kerguelen Archipelago">Kerguelen Archipelago</option>
                    <option value="Kingman Reef">Kingman Reef</option>
                    <option value="Kiribati">Kiribati</option>
                    <option value="Kosovo">Kosovo</option>
                    <option value="Kyrgyzstan">Kyrgyzstan</option>
                    <option value="Laos">Laos</option>
                    <option value="Latvia">Latvia</option>
                    <option value="Lebanon">Lebanon</option>
                    <option value="Lesotho">Lesotho</option>
                    <option value="Liberia">Liberia</option>
                    <option value="Libya">Libya</option>
                    <option value="Liechtenstein">Liechtenstein</option>
                    <option value="Lithuania">Lithuania</option>
                    <option value="Luxembourg">Luxembourg</option>
                    <option value="Macau">Macau</option>
                    <option value="Macedonia">Macedonia</option>
                    <option value="Madagascar">Madagascar</option>
                    <option value="Malawi">Malawi</option>
                    <option value="Malaysia">Malaysia</option>
                    <option value="Maldives">Maldives</option>
                    <option value="Mali">Mali</option>
                    <option value="Malta">Malta</option>
                    <option value="Marshall Islands">Marshall Islands</option>
                    <option value="Martinique">Martinique</option>
                    <option value="Mauritania">Mauritania</option>
                    <option value="Mauritius">Mauritius</option>
                    <option value="Mayotte">Mayotte</option>
                    <option value="Mexico">Mexico</option>
                    <option value="Micronesia">Micronesia</option>
                    <option value="Midway Islands">Midway Islands</option>
                    <option value="Moldova">Moldova</option>
                    <option value="Monaco">Monaco</option>
                    <option value="Mongolia">Mongolia</option>
                    <option value="Montenegro">Montenegro</option>
                    <option value="Montserrat">Montserrat</option>
                    <option value="Morocco">Morocco</option>
                    <option value="Mozambique">Mozambique</option>
                    <option value="Myanmar">Myanmar</option>
                    <option value="Namibia">Namibia</option>
                    <option value="Nauru">Nauru</option>
                    <option value="Navassa Island">Navassa Island</option>
                    <option value="Nepal">Nepal</option>
                    <option value="Netherlands">Netherlands</option>
                    <option value="Netherlands Antilles">Netherlands Antilles</option>
                    <option value="New Caledonia">New Caledonia</option>
                    <option value="New Zealand">New Zealand</option>
                    <option value="Nicaragua">Nicaragua</option>
                    <option value="Niger">Niger</option>
                    <option value="Nigeria">Nigeria</option>
                    <option value="Niue">Niue</option>
                    <option value="Norfolk Island">Norfolk Island</option>
                    <option value="Northern Mariana Islands">Northern Mariana Islands</option>
                    <option value="North Korea">North Korea</option>
                    <option value="Norway">Norway</option>
                    <option value="Pacific Ocean">Pacific Ocean</option>
                    <option value="Pakistan">Pakistan</option>
                    <option value="Palau">Palau</option>
                    <option value="Palmyra Atoll">Palmyra Atoll</option>
                    <option value="Panama">Panama</option>
                    <option value="Papua New Guinea">Papua New Guinea</option>
                    <option value="Paracel Islands">Paracel Islands</option>
                    <option value="Paraguay">Paraguay</option>
                    <option value="Peru">Peru</option>
                    <option value="Philippines">Philippines</option>
                    <option value="Pitcairn Islands">Pitcairn Islands</option>
                    <option value="Poland">Poland</option>
                    <option value="Portugal">Portugal</option>
                    <option value="Puerto Rico">Puerto Rico</option>
                    <option value="Republic of the Congo">Republic of the Congo</option>
                    <option value="Reunion">Reunion</option>
                    <option value="Romania">Romania</option>
                    <option value="Russia">Russia</option>
                    <option value="Rwanda">Rwanda</option>
                    <option value="Saint Helena">Saint Helena</option>
                    <option value="Saint Kitts and Nevis">Saint Kitts and Nevis</option>
                    <option value="Saint Lucia">Saint Lucia</option>
                    <option value="Saint Pierre and Miquelon">Saint Pierre and Miquelon</option>
                    <option value="Saint Vincent and the Grenadines">Saint Vincent and the Grenadines</option>
                    <option value="Samoa">Samoa</option>
                    <option value="San Marino">San Marino</option>
                    <option value="Sao Tome and Principe">Sao Tome and Principe</option>
                    <option value="Senegal">Senegal</option>
                    <option value="Serbia">Serbia</option>
                    <option value="Seychelles">Seychelles</option>
                    <option value="Sierra Leone">Sierra Leone</option>
                    <option value="Singapore">Singapore</option>
                    <option value="Slovakia">Slovakia</option>
                    <option value="Slovenia">Slovenia</option>
                    <option value="Solomon Islands">Solomon Islands</option>
                    <option value="Somalia">Somalia</option>
                    <option value="South Africa">South Africa</option>
                    <option value="South Georgia">South Georgia</option>
                    <option value="South Korea">South Korea</option>
                    <option value="Spain">Spain</option>
                    <option value="Spratly Islands">Spratly Islands</option>
                    <option value="Sri Lanka">Sri Lanka</option>
                    <option value="Sudan">Sudan</option>
                    <option value="Suriname">Suriname</option>
                    <option value="Svalbard">Svalbard</option>
                    <option value="Swaziland">Swaziland</option>
                    <option value="Sweden">Sweden</option>
                    <option value="Switzerland">Switzerland</option>
                    <option value="Syria">Syria</option>
                    <option value="Taiwan">Taiwan</option>
                    <option value="Tajikistan">Tajikistan</option>
                    <option value="Tanzania">Tanzania</option>
                    <option value="Thailand">Thailand</option>
                    <option value="Togo">Togo</option>
                    <option value="Tokelau">Tokelau</option>
                    <option value="Tonga">Tonga</option>
                    <option value="Trinidad and Tobago">Trinidad and Tobago</option>
                    <option value="Tromelin Island">Tromelin Island</option>
                    <option value="Tunisia">Tunisia</option>
                    <option value="Turkey">Turkey</option>
                    <option value="Turkmenistan">Turkmenistan</option>
                    <option value="Turks and Caicos Islands">Turks and Caicos Islands</option>
                    <option value="Tuvalu">Tuvalu</option>
                    <option value="Uganda">Uganda</option>
                    <option value="Ukraine">Ukraine</option>
                    <option value="Uruguay">Uruguay</option>
                    <option value="Uzbekistan">Uzbekistan</option>
                    <option value="Vanuatu">Vanuatu</option>
                    <option value="Venezuela">Venezuela</option>
                    <option value="Viet Nam">Viet Nam</option>
                    <option value="Virgin Islands">Virgin Islands</option>
                    <option value="Wake Island">Wake Island</option>
                    <option value="Wallis and Futuna">Wallis and Futuna</option>
                    <option value="West Bank">West Bank</option>
                    <option value="Western Sahara">Western Sahara</option>
                    <option value="Yemen">Yemen</option>
                    <option value="Yugoslavia">Yugoslavia</option>
                    <option value="Zambia">Zambia</option>
                    <option value="Zimbabwe">Zimbabwe</option>

                </select>
                <span class="err-msg" id="country-err">Select Country</span>
            </li>
            <li>
                <label class="citystate">City/State</label>
                <select id="j_id0:enq_frm:pageblock1:div_city_dropdown" name="00N20000001SJm3" class="city_dropdown cs1 alignright" title="City(R)" style="display:inline-block;">
                    <option value="">-- Select City --</option>
                    

                </select>
                <select id="j_id0:enq_frm:pageblock1:statelist_id" name="j_id0:enq_frm:pageblock1:statelist_id" class="form_textfield state_us alignright" size="1" style="display: none;">
                    <option value="">-- Select State --</option>
                    
                </select>
                <input id="j_id0:enq_frm:pageblock1:div_city" maxlength="40" name="city_input" size="22" type="text" class="city_input alignright" style="display: none;margin-bottom:5px;" />
                <span class="err-msg" id="city-err">Enter City</span>
                <span class="err-msg" id="city-err1">Select City/State</span>
                <span class="err-msg" id="state-err">Select State</span>
                <span class="err-msg" id="city-err2">Please enter valid City</span>
            </li>
            <li class="mobile">
                 <label>Mobile</label>
				<input type="" value="+91" id="c_code" disabled style="width:20%; float:left; text-align:center; margin-bottom:14px;" >
                <input id="j_id0:enq_frm:pageblock1:mobile2" name="mobile_no_abc" class="mobile_no_get m2" size="10" type="number" />
                <span class="err-msg" id="mobile-err">Please enter a mobile number.</span>
                <span class="err-msg" id="mobile_zero"> Mobile number should not begin with zero.</span>
                <span class="err-msg" id="mobile-err1">Please enter valid mobile no.</span>
                <span class="err-msg" id="mobile_max">Mobile number must be a 10 digit number.</span>
                <p id="verificationdiv" class="vText"></p>
                <!--p id="verificationdiv" class="vText">Click here to validate your mobile number</p-->
                <p id="VerificationBlock" class="vInput">
                <a class="casa_submit_btn" href="#" id="GenCodeLink" ><span class="veriFcode">Verify &#10095;</span></a>
                <p class="veri-pass" id="veri_pass">
				<label style="width:100%;font-size: 1em;">verification Password</label><!--<span>Enter verification<br/> password</span>--><input type="number" size="4" maxlength="4" id="j_id0:enq_frm:pageblock1:ConfirmationCode" class="code" placeholder=""></p>
                <span id="processing_msg_code" style="display:none;">Sending code...</span>
                <span class="err-msg" id="ConfirmationCode-err">Invalid Code </span></p>
            </li>
            <li class="clearfix" style="display:none">
                <label class="llLabel">Landline</label>
                <div class="llinputs">
                    <input maxlength="7" size="5" type="text" name="landline_ext" id="j_id0:enq_frm:pageblock1:phone1" class="ext ext_country_prefix ll1" value="0091">
                    <input size="4" type="text" name="landline_std" id="j_id0:enq_frm:pageblock1:phone2" class="ext ext_std_res_phone ll2">
                    <input style="width:60px;" id="j_id0:enq_frm:pageblock1:phone3" maxlength="40" name="phone_conc" class="res_no ll2" size="20" type="text" />
                </div>
                <span class="err-msg" id="landline-err">Enter your Landline number</span>
                <span class="err-msg" id="landline-err1">STD code should begin with 0.</span>
                <span class="err-msg" id="landline-code-err">Please enter a valid STD code</span>
                <span class="err-msg" id="landline-err2">Please enter a valid Landline number </span>
            </li>
            <li class="btnRow">
                <input class="casa_submit_btn button" id="SubmitLeadLink" type="submit" value="Submit &#10095;"/>
            </li>
        </ul>
    </div>   
</div>
<!--<input type="hidden" name="Cluster_Name__c" id="Cluster_Name__c" value="Lodha Parkside"><!--WR 652 priyanka prashant-->
<!-- <input type="hidden" name="00ND00000039gka"  value="a09D000001Gxr3j"> business class project id -->
<!--<input type="hidden" name="Project_Interested__c" id="Project_Interested__c" value="New Cuffe Parade"><!-- Shashank - 26th September 2014-->
<input type="hidden" id="projid" name="00ND00000039gka" value="<?php echo PROJECT_ID;?>">
<input type="hidden" name="oid" value="00D20000000Hu8V">
<input type="hidden" name="recordType" value="0122000000098Zo" />
<input type="hidden" id="retURL" name="retURL" value="<?php echo retURL;?>">
<input type="hidden" name="lead_source" id="lead_source" value="Web" />
<input name="00N20000001l1Ix" type="hidden" id="00N20000001l1Ix" size="35" maxlength="50" title="Web banner Source" value="<?php echo $_COOKIE[COOKIE_NAME."_publisher"]; ?>">
<input id="00N200000020mNQ" name="00N200000020mNQ" type="hidden" value="<?php echo $_COOKIE[COOKIE_NAME."_campaign"]; ?>" />
<input type="hidden" name="00N20000001SJm3" class="city_send" />
<input size="5" max-length="7" type="hidden" name="mobile_ext" id="j_id0:enq_frm:pageblock1:mobile1" class="ext ext_mob m1" value="0091">
<input type="hidden" class="mobile_no_fetch" name="00N20000001SJmb" />
<input type="hidden" name="phone" id="phone_con" />
<input id="j_id0:enq_frm:pageblock1:recvalue" type="hidden" name="j_id0:enq_frm:pageblock1:recvalue" value="Residential">
<input id="j_id0:enq_frm:pageblock1:allowmobileverification" type="hidden" name="j_id0:enq_frm:pageblock1:allowmobileverification" value="true"> 
<input id="j_id0:enq_frm:pageblock1:allowcallpatching" type="hidden" name="j_id0:enq_frm:pageblock1:allowcallpatching" value="true">
<input id="j_id0:enq_frm:pageblock1:callcenterno" type="hidden" name="j_id0:enq_frm:pageblock1:callcenterno" value="2266429966">
<input id="j_id0:enq_frm:pageblock1:CompanyName1" type="hidden" name="j_id0:enq_frm:pageblock1:CompanyName1">
<input id="j_id0:enq_frm:pageblock1:CheckCode" type="hidden" name="j_id0:enq_frm:pageblock1:CheckCode">
<input id="projectId" type="hidden" name="projectId" value="a09D000001Gxr3j">
    <!--flt_right ends here-->

<!-- additional fields -->


<?php 
// get width and height

/* $width = $_COOKIE['width'];
$height = $_COOKIE['height'];

$resolution = $width.'*'. $height; */
   
//landing page url

$landing_page_url = "http://$_SERVER[HTTP_HOST]$_SERVER[REQUEST_URI]";

// get browser detail 

$agent = $_SERVER['HTTP_USER_AGENT']; 
// Get the user Browser now -----------------------------------------------------
// Create the Associative Array for the browsers we want to sniff out
$browserArray = array(
        'Windows Mobile' => 'IEMobile',
		'Android Mobile' => 'Android',
		'iPhone Mobile' => 'iPhone',
		'Firefox' => 'Firefox',
        'Google Chrome' => 'Chrome',
        'Internet Explorer' => 'MSIE',
        'Opera' => 'Opera',
        'Safari' => 'Safari'
); 
foreach ($browserArray as $k => $v) {

    if (preg_match("/$v/", $agent)) {
         break;
    }	else {
	 $k = "Browser Unknown";
    }
} 
$browser = $k;

// Get the user OS now ------------------------------------------------------------
// Create the Associative Array for the Operating Systems to sniff out
$osArray = array(
        'Windows 98' => '(Win98)|(Windows 98)',
        'Windows 2000' => '(Windows 2000)|(Windows NT 5.0)',
		'Windows ME' => 'Windows ME',
        'Windows XP' => '(Windows XP)|(Windows NT 5.1)',
        'Windows Vista' => 'Windows NT 6.0',
        'Windows 7' => '(Windows NT 6.1)|(Windows NT 7.0)',
        'Windows NT 4.0' => '(WinNT)|(Windows NT 4.0)|(WinNT4.0)|(Windows NT)',
		'Linux' => '(X11)|(Linux)',
		'Mac OS' => '(Mac_PowerPC)|(Macintosh)|(Mac OS)'
); 
foreach ($osArray as $k => $v) {

    if (preg_match("/$v/", $agent)) {
         break;
    }	else {
	 $k = "Unknown OS";
    }
} 
$os = $k;
// At this point you can do what you wish with both the OS and browser acquired

// Function to get the client ip address
//$ip=$_SERVER['REMOTE_ADDR'];

// To detect device ie: mobile, tab or pc

$tablet_browser = 0;
$mobile_browser = 0;
 
if (preg_match('/(tablet|ipad|playbook)|(android(?!.*(mobi|opera mini)))/i', strtolower($_SERVER['HTTP_USER_AGENT']))) {
    $tablet_browser++;
}
 
if (preg_match('/(up.browser|up.link|mmp|symbian|smartphone|midp|wap|phone|android|iemobile)/i', strtolower($_SERVER['HTTP_USER_AGENT']))) {
    $mobile_browser++;
}
 
if ((strpos(strtolower($_SERVER['HTTP_ACCEPT']),'application/vnd.wap.xhtml+xml') > 0) or ((isset($_SERVER['HTTP_X_WAP_PROFILE']) or isset($_SERVER['HTTP_PROFILE'])))) {
    $mobile_browser++;
}
 
$mobile_ua = strtolower(substr($_SERVER['HTTP_USER_AGENT'], 0, 4));
$mobile_agents = array(
    'w3c ','acs-','alav','alca','amoi','audi','avan','benq','bird','blac',
    'blaz','brew','cell','cldc','cmd-','dang','doco','eric','hipt','inno',
    'ipaq','java','jigs','kddi','keji','leno','lg-c','lg-d','lg-g','lge-',
    'maui','maxo','midp','mits','mmef','mobi','mot-','moto','mwbp','nec-',
    'newt','noki','palm','pana','pant','phil','play','port','prox',
    'qwap','sage','sams','sany','sch-','sec-','send','seri','sgh-','shar',
    'sie-','siem','smal','smar','sony','sph-','symb','t-mo','teli','tim-',
    'tosh','tsm-','upg1','upsi','vk-v','voda','wap-','wapa','wapi','wapp',
    'wapr','webc','winw','winw','xda ','xda-');
 
if (in_array($mobile_ua,$mobile_agents)) {
    $mobile_browser++;
}
 
if (strpos(strtolower($_SERVER['HTTP_USER_AGENT']),'opera mini') > 0) {
    $mobile_browser++;
    //Check for tablets on opera mini alternative headers
    $stock_ua = strtolower(isset($_SERVER['HTTP_X_OPERAMINI_PHONE_UA'])?$_SERVER['HTTP_X_OPERAMINI_PHONE_UA']:(isset($_SERVER['HTTP_DEVICE_STOCK_UA'])?$_SERVER['HTTP_DEVICE_STOCK_UA']:''));
    if (preg_match('/(tablet|ipad|playbook)|(android(?!.*mobile))/i', $stock_ua)) {
      $tablet_browser++;
    }
}
 
if ($tablet_browser > 0) {
   // do something for tablet devices
   $device = 'tablet';
}
else if ($mobile_browser > 0) {
   // do something for mobile devices
    $device = 'mobile';
}
else { 
   // do something for everything else
    $device = 'desktop';
}   

// To detect device name of user

require_once 'mobile_detect.php';
$detect = new Mobile_Detect;

$deviceType = ($detect->isMobile() ? ($detect->isTablet() ? 'tablet' : 'phone') : 'computer');
$scriptVersion = $detect->getScriptVersion();

if($_COOKIE["splendora"] == "Publisher"){
	$banner_size = $_SESSION["pixel_timestamp"]; 
} //else{ 	$banner_size = $_COOKIE[COOKIE_NAME.'_banner_size']; } ?>
 
<!--URL Tagging	form fields -->
<input 	type="hidden" name="Banner_Size__c" id="Banner_Size__c" value="<?php echo $banner_size; ?>">
<input  type="hidden" name="Digital_Source__c" id="Digital_Source__c" value="<?php echo $digital_source; ?>">	
<input  type="hidden" name="Digital_Medium__c" id="Digital_Medium__c" value="<?php echo $digital_medium; ?>">
<input  type="hidden" name="Keyword__c" id="Keyword__c" value="<?php echo $keyword; ?>">
<input  type="hidden" name="Placement__c" id="Placement__c" value="<?php echo $placement; ?>">
<input  type="hidden" name="Adgroup__c" id="Adgroup__c" value="<?php echo $adgroup; ?>">	
<input  type="hidden" name="Adposition__c" id="Adposition__c" value="<?php echo $adposition; ?>">	
<input  type="hidden" name="Matchtype__c" id="Matchtype__c" value="<?php echo $matchtype; ?>">	
<input  type="hidden" name="Network__c" id="Network__c" value="<?php echo $network; ?>">
<input  type="hidden" name="GCLID__c" id="GCLID__c" value="<?php echo $gclid; ?>">
<input  type="hidden" name="Visitor_Type__c" id="Visitor_Type__c" value="<?php echo $visitor_type; ?>">
 

<!--  Form Code fields  -->
<input 	type="hidden" name="Browser__c" id="Browser__c" value="<?php echo $browser;?>">	
<input  type="hidden" name="Device__c" id="Device__c" value="<?php echo $device;?>">	
<input  type="hidden" name="Device_Name__c" id="Device_Name__c" value="<?php echo $deviceType;?>">	
<input  type="hidden" name="First_Visit__c" id="First_Visit__c" value="<?php echo $_COOKIE["First_Visit__c"];?>">	
<input  type="hidden" name="Form_Tracker__c" id="Form_Tracker__c" value="Form_Tracker__c">	
<input  type="hidden" name="IP_Address__c" id="IP_Address__c" value="" id="IP_Address__c">		
<input  type="hidden" name="Landing_Page_URL__c" id="Landing_Page_URL__c" value="<?php echo $landing_page_url; ?>">	
<input  type="hidden" name="OS__c" id="OS__c" value="<?php echo $os;?>">	
<input  type="hidden" id="Resolution__c" name="Resolution__c" value="">	
<input 	type="hidden" id="Time_Spent_before_Form_Submit__c" name="Time_Spent_before_Form_Submit__c" value="">	
<input  type="hidden" name="Visit_Duration__c" id="Visit_Duration__c" value="Visit_Duration__c">





</form>
<!--<script type="application/javascript">
    function getip(json){
      //alert(json.ip); // alerts the ip address
	  $("#IP_Address__c").val(json.ip);
    }
</script>
<script type="application/javascript" src="http://www.telize.com/jsonip?callback=getip"></script>-->
<script type="text/javascript" src="https://l2.io/ip.js?var=userip"></script>
<script type="text/javascript">
  $("#IP_Address__c").val(userip);
</script>
<style>
input[type=number]::-webkit-inner-spin-button, 
input[type=number]::-webkit-outer-spin-button { 
  -webkit-appearance: none; 
  margin: 0; 
}
</style> 