<?php
namespace phpbu\App\Factory;

/**
 * Class FakeNothing
 *
 * Dummy class to test phpbu Factory create methods.
 */
class FakeNothing
{
    /**
     * Do nothing.
     */
    public function doNothing()
    {
        // do something fooish
    }
}
