<?php
namespace phpbu\App;

/**
 * Factory test
 *
 * @package    phpbu
 * @subpackage tests
 * @author     Sebastian Feldmann <sebastian@phpbu.de>
 * @copyright  Sebastian Feldmann <sebastian@phpbu.de>
 * @license    https://opensource.org/licenses/MIT The MIT License (MIT)
 * @link       https://www.phpbu.de/
 * @since      Class available since Release 1.1.5
 */
class FactoryTest extends \PHPUnit\Framework\TestCase
{
    /**
     * Tests Factory::createAdapter
     */
    public function testCreateAdapter()
    {
        $factory = new Factory();
        $adapter = $factory->createAdapter('env', []);

        $this->assertEquals('phpbu\\App\\Adapter\\Env', get_class($adapter), 'adapter classes should match');
    }

    /**
     * Tests Factory::createTarget
     */
    public function testCreateTarget()
    {
        $directory = sys_get_temp_dir() . '/test-dir';
        $conf      = new Configuration\Backup\Target($directory, 'test-file', 'bzip2');
        $factory   = new Factory();
        $target    = $factory->createTarget($conf);

        $this->assertEquals('phpbu\\App\\Backup\\Target', get_class($target), 'should be a target');
        $this->assertEquals('test-file.bz2', $target->getFilename());
        $this->assertEquals($directory . '/test-file.bz2', $target->getPathname());

        $this->assertTrue(file_exists($directory));

        rmdir($directory);
    }

    /**
     * Tests Factory::createSource
     */
    public function testCreateSource()
    {
        // register dummy source, all default sources have system dependencies like cli binaries
        Factory::register('source', 'dummy', '\\phpbu\\App\\Backup\\Source\\FakeSource');
        $factory = new Factory();
        $source  = $factory->createSource('dummy', []);

        $this->assertEquals('phpbu\\App\\Backup\\Source\\FakeSource', get_class($source), 'classes should match');
    }

    /**
     * Tests Factory::createLogger
     */
    public function testCreateLogger()
    {
        $factory = new Factory();
        $logger  = $factory->createLogger('mail', ['recipients' => 'no-reply@phpbu.de']);

        $this->assertEquals('phpbu\\App\\Log\\Mail', get_class($logger), 'classes should match');
    }

    /**
     * Tests Factory::createCheck
     */
    public function testCreateCheck()
    {
        $factory = new Factory();
        $check  = $factory->createCheck('sizemin');

        $this->assertEquals('phpbu\\App\\Backup\\Check\\SizeMin', get_class($check), 'classes should match');
    }

    /**
     * Tests Factory::createCrypter
     */
    public function testCreateCrypter()
    {
        Factory::register('crypter', 'dummy', '\\phpbu\\App\\Backup\\Crypter\\FakeCrypter');

        $factory = new Factory();
        $crypter = $factory->createCrypter('dummy', []);

        $this->assertEquals('phpbu\\App\\Backup\\Crypter\\FakeCrypter', get_class($crypter), 'classes should match');
    }

    /**
     * Tests Factory::createSync
     */
    public function testCreateSync()
    {
        $factory = new Factory();
        $sync    = $factory->createSync('Rsync', ['args' => 'foo']);

        $this->assertEquals('phpbu\\App\\Backup\\Sync\\Rsync', get_class($sync), 'classes should match');
    }

    /**
     * Tests Factory::createCleaner
     */
    public function testCreateCleaner()
    {
        $factory = new Factory();
        $sync    = $factory->createCleaner('Capacity', ['size' => '10M']);

        $this->assertEquals('phpbu\\App\\Backup\\Cleaner\\Capacity', get_class($sync), 'classes should match');
    }

    /**
     * Tests Factory::createType
     *
     * @expectedException \phpbu\App\Exception
     */
    public function testCreateUnknown()
    {
        $factory = new Factory();
        $factory->createSync('Unknown', ['foo' => 'bar']);

        $this->assertFalse(true, 'exception should be thrown');
    }

    /**
     * Tests Factory::register
     */
    public function testRegisterCheckOk()
    {
        Factory::register('check', 'dummy', '\\phpbu\\App\\Backup\\Check\\FakeCheck');

        $factory = new Factory();
        $dummy   = $factory->createCheck('dummy');

        $this->assertEquals(
            'phpbu\\App\\Backup\\Check\\FakeCheck',
            get_class($dummy),
            'Factory should create dummy object'
        );
    }

    /**
     * Tests Factory::register
     *
     * @expectedException \phpbu\App\Exception
     */
    public function testRegisterInvalidType()
    {
        Factory::register('invalid', 'dummy', '\\phpbu\\App\\PhpbuAppFactoryTestCheck');

        $this->assertFalse(true, 'Exception should be thrown');
    }

    /**
     * Tests Factory::createAdapter
     *
     * @expectedException \phpbu\App\Exception
     */
    public function testCreateAdapterThatIsNone()
    {
        Factory::register('adapter', 'nothing', '\\phpbu\\App\\Factory\\FakeNothing', true);

        $factory = new Factory();
        $factory->createAdapter('nothing');

        $this->assertFalse(true, 'Exception should be thrown');
    }

    /**
     * Tests Factory::createSource
     *
     * @expectedException \phpbu\App\Exception
     */
    public function testCreateSourceThatIsNone()
    {
        Factory::register('source', 'nothing', '\\phpbu\\App\\Factory\\FakeNothing', true);

        $factory = new Factory();
        $factory->createSource('nothing');

        $this->assertFalse(true, 'Exception should be thrown');
    }

    /**
     * Tests Factory::createSource
     *
     * @expectedException \phpbu\App\Exception
     */
    public function testCreateCrypterThatIsNone()
    {
        Factory::register('crypter', 'nothing', '\\phpbu\\App\\Factory\\FakeNothing', true);

        $factory = new Factory();
        $factory->createCrypter('nothing');

        $this->assertFalse(true, 'Exception should be thrown');
    }

    /**
     * Tests Factory::createLogger
     *
     * @expectedException \phpbu\App\Exception
     */
    public function testCreateLoggerThatIsNone()
    {
        Factory::register('logger', 'nothing', '\\phpbu\\App\\Factory\\FakeNothing', true);

        $factory = new Factory();
        $factory->createLogger('nothing');

        $this->assertFalse(true, 'Exception should be thrown');
    }

    /**
     * Tests Factory::createLogger
     *
     * @expectedException \phpbu\App\Exception
     */
    public function testCreateLoggerThatIsLoggerButNoListener()
    {
        Factory::register('logger', 'nothing', '\\phpbu\\App\\Log\\FakeLoggerNoListener', true);

        $factory = new Factory();
        $factory->createLogger('nothing');

        $this->assertFalse(true, 'Exception should be thrown');
    }

    /**
     * Tests Factory::createCleaner
     *
     * @expectedException \phpbu\App\Exception
     */
    public function testCreateCleanerThatIsNone()
    {
        Factory::register('cleaner', 'nothing', '\\phpbu\\App\\Factory\\FakeNothing', true);

        $factory = new Factory();
        $factory->createCleaner('nothing');

        $this->assertFalse(true, 'Exception should be thrown');
    }

    /**
     * Tests Factory::createCleaner
     *
     * @expectedException \phpbu\App\Exception
     */
    public function testCreateSyncThatIsNone()
    {
        Factory::register('sync', 'nothing', '\\phpbu\\App\\Factory\\FakeNothing', true);

        $factory = new Factory();
        $factory->createSync('nothing');

        $this->assertFalse(true, 'Exception should be thrown');
    }

    /**
     * Tests Factory::createCleaner
     *
     * @expectedException \phpbu\App\Exception
     */
    public function testCreateCheckThatIsNone()
    {
        Factory::register('check', 'nothing', '\\phpbu\\App\\Factory\\FakeNothing', true);

        $factory = new Factory();
        $factory->createCheck('nothing');

        $this->assertFalse(true, 'Exception should be thrown');
    }

    /**
     * Tests Factory::createRunner
     *
     * @expectedException \phpbu\App\Exception
     */
    public function testCreateRunnerThatIsNone()
    {
        Factory::register('runner', 'nothing', '\\phpbu\\App\\Factory\\FakeNothing', true);

        $factory = new Factory();
        $factory->createRunner('nothing', false);

        $this->assertFalse(true, 'Exception should be thrown');
    }

    /**
     * Tests Factory::register
     *
     * @expectedException \phpbu\App\Exception
     */
    public function testRegisterExistingCheck()
    {
        Factory::register('check', 'sizemin', '\\phpbu\\App\\Backup\\Check\\FakeCheck');

        $this->assertFalse(true, 'Exception should be thrown');
    }

    /**
     * Tests Factory::register
     *
     * @depends testRegisterExistingCheck
     */
    public function testRegisterExistingCheckForce()
    {
        Factory::register('check', 'sizemin', '\\phpbu\\App\\Backup\\Check\\FakeCheck', true);

        $factory = new Factory();
        $dummy   = $factory->createCheck('sizemin');

        $this->assertEquals(
            get_class($dummy),
            'phpbu\\App\\Backup\\Check\\FakeCheck',
            'Factory should create dummy object'
        );
    }
}
