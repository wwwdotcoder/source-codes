<?php
define('BOOTSTRAP_LOADED', true);
