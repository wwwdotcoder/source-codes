<?php
define('BOOTSTRAP_OPTION_LOADED', true);
