<?php
return [
    'foo' => [
        'bar' => [
            'baz' => 'fiz'
        ]
    ]
];
