<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="">
    <meta name="author" content="">

    <title>Priva lodha group</title>
	
    <!-- css -->
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <link href="font-awesome/css/font-awesome.min.css" rel="stylesheet" type="text/css" />
	<link href="css/animations.css" rel="stylesheet" />
    <link href="css/style.css" rel="stylesheet">
	<link href="css/default.css" rel="stylesheet">
    <link href="css/selectBx.css" rel="stylesheet"/>
<style type="text/css">
label.error {
    color: #f00;
    font-weight: bold;
}
.refer-bottom-space{
  padding-bottom: 5px;
}
</style>

</head>

<body id="page-top" data-spy="scroll" data-target=".navbar-custom">

    <!-- Navigation -->
    <div id="navigation">
        <nav class="navbar navbar-custom" role="navigation">
                              <div class="container">
                                    <div class="row">
                                          <div class="col-md-2">
                                                   <div class="site-logo">
                                                            <a href="index.php" class="brand"><img src="images/Priva Logo.png" width="118" height="51"  alt=""/></a>
                                                    </div>
                                          </div>                                                                                    
                                    </div>
                              </div>
                              <!-- /.container -->
                        </nav>
    </div> 
    <!-- /Navigation --> 
    
	<!-- Section: MY DETAILS -->
    <section id="MyDetails" class="home-section color-dark bg-white">
		<div class="container marginbot-20">
			<div class="row">
				<div class="col-lg-8 col-lg-offset-2">
					<div class="animatedParent">
					<div class="section-heading text-center animated xbounceInDown">
					<h6 class="text-lgt-blue">REFER YOUR LOVED ONES TO THE LODHA LIFE!</h6>
					
					<p>As your referrals get exclusive deals & discounts, you will get exciting benefits & rewards.</p>					
					</div>
					</div>
				</div>
			</div>
		</div>

		<div class="container">		
        <div class="row">				
            <div class="col-lg-8 col-lg-offset-2 animatedParent">
                <h5 class="text-lgt-blue text-center">MY DETAILS</h5>		
				<form id="contact-form" class="form-horizontal" action="submit.php" method="post">
				<input type="hidden" id="crn_flag" value="">
						<div class="form-group">
							<label class="col-md-3 colon-symble">
								Name*
							</label>
							<div class="col-md-8">
								<div class="row">
                                    <div class="col-md-6 xs-marginbot-20">
                                        <input type="text" name="fname" class="form-control" placeholder="First Name" required />
                                    </div>
                                    <div class="col-md-6">
                                        <input type="text" name="lname" class="form-control" placeholder="Last Name" required />
                                    </div>
                                </div>
							</div>
						</div>
						<div class="form-group">
							<label class="col-md-3 colon-symble">
								Mobile*
							</label>
							<div class="col-md-8">
								<div class="row">
                                    <div class="col-md-12">
                                        <input type="number" name="mobile" class="form-control" placeholder="Mobile Number" required />
                                    </div>                                    
                                </div>
							</div>
						</div>
                        
                        <div class="form-group">
							<label class="col-md-3 colon-symble">
								Email*
							</label>
							<div class="col-md-8">
								<div class="row">
                                    <div class="col-md-12">
                                        <input type="email" name="email" class="form-control" placeholder="Email ID" required />
                                    </div>                                    
                                </div>
							</div>
						</div>
                        
                        <div class="form-group">
							<label class="col-md-3 colon-symble">
								
							</label>
							<div class="col-md-1">
								<div class="row">
                                    <div class="col-md-12">
                                        <input type="checkbox" name="agree" value="1" style="margin:10px 5px 0px 0px;float: left;">
                                    </div>                                    
                                </div>
							</div>
							<div class="col-md-7">
								<label class="col-md-12 colon-symble">
								I would be interested in buying a Lodha Property.
								</label>
								
							</div>
						</div>
                        <div class="form-group">
							<div class="col-md-12">
								<h5 class="text-lgt-blue text-center">MY REFERENCES</h5>	
							</div>
						</div>
                        <div class="form-group">
							<label class="col-md-3 colon-symble">
								Reference 1
							</label>
							<div class="col-md-8" style="padding: 0px;">
							<div class="col-md-4 refer-bottom-space">
								
                                        <input type="text" name="name1" id="name1" placeholder="Name" class="form-control">
                                   
							</div>
							<div class="col-md-4 refer-bottom-space">
								
                                        <input type="number" name="mobile1" id="mobile1" placeholder="Mobile" class="form-control">
                                   
							</div>
							<div class="col-md-4 refer-bottom-space">
								
								<select class="form-control" id="relation1" name="relation1">
										<option value="">-- Relation --</option>
										<option value="Friend">Friend</option>
										<option value="Family Member">Family Member</option>
										<option value="Colleague">Colleague</option>
								</select> 
                                   
							</div>
							</div>
						</div>
                        
                        <div class="form-group">
							<label class="col-md-3 colon-symble">
								Reference 2
							</label>
							<div class="col-md-8" style="padding: 0px;">
							<div class="col-md-4 refer-bottom-space">
								
                                        <input type="text" name="name2" id="name2" placeholder="Name" class="form-control">
                                   
							</div>
							<div class="col-md-4 refer-bottom-space">
								
                                        <input type="number" name="mobile2" id="mobile2" placeholder="Mobile" class="form-control">
                                   
							</div>
							<div class="col-md-4 refer-bottom-space">
								
                                    <select class="form-control" id="relation2" name="relation2">
										<option value="">-- Relation --</option>
										<option value="Friend">Friend</option>
										<option value="Family Member">Family Member</option>
										<option value="Colleague">Colleague</option>
									</select>
                                   
							</div>
							</div>
						</div>
						
						<span id="appendinputs" style="margin-top: 5px;" ></span>
						
						<div class="form-group">
							<label class="col-md-3 ">
								
							</label>
							<div class="col-md-8 margintop-30">
								<button class="btn btn-blue" type="button" id="Refadd" style="float: right;">+</button> 
							</div>
						</div>
						
                        
                        <div class="clearfix"></div>
                        <div class="form-group">
							<div class="col-md-12 margintop-30 text-center">
								<button class="btn btn-blue" type="submit" >&nbsp; &nbsp; &nbsp; &nbsp; Submit &#10095; &nbsp; &nbsp; &nbsp; &nbsp;</button> 
							</div>
						</div>
						</form>
            </div>		                
        </div>		
		</div>
	</section>
	<!-- /Section: MY DETAILS -->	


<footer>
    <div class="container text-left"> 
     <a href="#"><img src="images/Lodha Logo.png" width="151" height="21"  alt=""/></a> 
   </div>
</footer>

    <!-- Core JavaScript Files -->
    <script src="js/jquery.min.js"></script>	 
    <script src="js/jquery.validate.min.js"></script>	
    <script src="js/bootstrap_3.2.min.js"></script>	
    <!--script src="http://maxcdn.bootstrapcdn.com/bootstrap/3.2.0/js/bootstrap.min.js"></script-->
	<script src="js/jquery.sticky.js"></script>
	<script src="js/jquery.appear.js"></script>	
    <script src="js/custom.js"></script>
	<script src="js/css3-animate-it.js"></script>
    <!--script src="js/selectbox-main.js"></script-->

<script>
//var $ =jQuery.noConflict();
	
$(function(){
	$.validator.addMethod(
             "regex",
             function(value, element, regexp) 
             {
                 if (regexp.constructor != RegExp)
                     regexp = new RegExp(regexp);
                 else if (regexp.global)
                     regexp.lastIndex = 0;
                 return this.optional(element) || regexp.test(value);
             },
             "Please check your name."    
	    );
       // Setup form validation on the #register-form element	
    $("#contact-form").validate({
    
        // Specify the validation rules
        rules: {
            fname: {
                required: true,
                regex: /^[a-zA-Z ]*$/,
            },
			lname: {
                required: true,
                regex: /^[a-zA-Z ]*$/,
            },
			email: {
                required: true,
                email: true,
            },
			mobile:{
				required:true,
				minlength:10,
				maxlength:10,
				digits: true,
			},	
			
			name1:{				
					required: function(){
					return $("#relation1").val().length > 0;
				},
			},	
   			mobile1:{				
				required: function(){
					return $("#name1").val().length > 0;
				},
				minlength:10,
				maxlength:10,
				digits: true,
   			},	   			
   			relation1:{				
				required: function(){
					return $("#name1").val().length > 0;
				},
				required: function(){
					return $("#mobile1").val().length > 0;
				},
			},	
			
			name2:{				
					required: function(){
					return $("#relation2").val().length > 0;
				},
			},	
   			mobile2:{
				required: function(){
					return $("#name2").val().length > 0;
				},
				minlength:10,
				maxlength:10,
				digits: true,
   			},	   			
   			relation2:{
				required: function(){
					return $("#name2").val().length > 0;
				},
				required: function(){
					return $("#mobile2").val().length > 0;
				},
			},
   			
			name3:{				
					required: function(){
					return $("#relation3").val().length > 0;
				},
			},	
   			mobile3:{				
				required: function(){
					return $("#name3").val().length > 0;
				},
				minlength:10,
				maxlength:10,
				digits: true,
   			},	   			
   			relation3:{				
				required: function(){
					return $("#name3").val().length > 0;
				},
				required: function(){
					return $("#mobile3").val().length > 0;
				},
			},	
			
			name4:{				
					required: function(){
					return $("#relation4").val().length > 0;
				},
			},	
   			mobile4:{				
				required: function(){
					return $("#name4").val().length > 0;
				},
				minlength:10,
				maxlength:10,
				digits: true,
   			},	   			
   			relation4:{				
				required: function(){
					return $("#name4").val().length > 0;
				},
				required: function(){
					return $("#mobile4").val().length > 0;
				},
			},	
			
			name5:{				
					required: function(){
					return $("#relation5").val().length > 0;
				},
			},	
   			mobile5:{				
				required: function(){
					return $("#name5").val().length > 0;
				},
				minlength:10,
				maxlength:10,
				digits: true,
   			},	   			
   			relation5:{				
				required: function(){
					return $("#name5").val().length > 0;
				},
				required: function(){
					return $("#mobile5").val().length > 0;
				},
			},	
			
        },
        
        // Specify the validation error messages
        messages: {
            fname: {
                required: 'Please enter your first name',
                regex: 'Please enter letter only'
            },
			lname: {
                required: 'Please enter your last name',
                regex: 'Please enter letter only'
            },
			mobile: {
                required: "Please enter a valid Mobile Number",
				digits: "Please enter a valid Mobile Number"
			},
			 email: {
                required: "Please enter a valid E-mail ID",
			},
			name1: {
                 required: "Please enter name"
			},
			name2: {
                 required: "Please enter name"
			},
			name3: {
                 required: "Please enter name"
			},
			name4: {
                 required: "Please enter name"
			},
			name5: {
                 required: "Please enter name"
			},
			mobile1: {
                required: "Please enter a valid Mobile Number",
				digits: "Please enter a valid Mobile Number"
			},
			mobile2: {
                required: "Please enter a valid Mobile Number",
				digits: "Please enter a valid Mobile Number"
			},
			mobile3: {
                required: "Please enter a valid Mobile Number",
				digits: "Please enter a valid Mobile Number"
			},
			mobile4: {
                required: "Please enter a valid Mobile Number",
				digits: "Please enter a valid Mobile Number"
			},
			mobile5: {
                required: "Please enter a valid Mobile Number",
				digits: "Please enter a valid Mobile Number"
			},
			relation1: {
                required: "Please select relation"
			},	
			relation2: {
                required: "Please select relation"
			},	
			relation3: {
                required: "Please select relation"
			},	
			relation4: {
                required: "Please select relation"
			},	
			relation5: {
                required: "Please select relation"
			}
			},
			
			submitHandler: function(form) {
				form.submit(); 
				return true;
				/* if($("#crn_flag").val() == "true"){
				
				}else{				
					alert("Your CRN No. is already registered for the event");
					return false;
				} */ 
			}		
    });//validation
 
var value=3;

$('#Refadd').on('click', function(){
	var $looking = $('select#looking');
    var $selfs = $('#appendinputs');
  
	$selfs.append(function () {
    var output = '';
	
	if(value < 6){
		output += '<div class="form-group"><label class="col-md-3 colon-symble">Reference '+value+'</label><div class="col-md-8" style="padding: 0px;"><div class="col-md-4 refer-bottom-space"><input type="text" name="name'+value+'" id="name'+value+'" placeholder="Name" class="form-control"></div><div class="col-md-4 refer-bottom-space"><input type="number" name="mobile'+value+'" id="mobile'+value+'" placeholder="Mobile" class="form-control"></div><div class="col-md-4 refer-bottom-space"><select class="form-control" id="relation'+value+'" name="relation'+value+'"><option value="">-- Relation --</option><option value="Friend">Friend</option><option value="Family Member">Family Member</option><option value="Colleague">Colleague</option></select></div></div></div>';
    }
    value++;
	return output;
    });
});

});//EODr
</script>	
</body>
</html>
