# Google API Map

Map is displayed to fit the user's current location and other markers.

Click on one of the other markers and the route will render from your current location to that marker.

[gh-pages](http://shanegibney.github.io/googleAPIcurrentLocation/)
