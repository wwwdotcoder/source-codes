<form method='post' action='index.php' enctype='multipart/form-data'>
    <input type='file' name='image' />
    <input type='submit' value='Submit' name='submit' />
</form>
<?php
if(isset($_POST['submit'])){	
//echo '<pre>'; print_r($_FILES['image']); exit;

    $path='images/';/* output path for images generated */
    $watermarksrc=realpath('watermark.png');

    if(isset($_FILES['image'])){

        $img_tmpname=$_FILES['image']['tmp_name'];
        $img_name=$_FILES['image']['name'];

        $num = substr(md5(mt_rand(1,9999999999)),0,9);
        $new_name = $path.$num."__".$img_name;
        $image = $num."__".$img_name;

        if(move_uploaded_file( $img_tmpname, $new_name ) ){
			
			if($_FILES['image']['type'] === 'image/png'){
				$image = imagecreatefrompng($new_name);
			}else{
				$image = imagecreatefromjpeg($new_name);				
			}				
            $logoImage = imagecreatefrompng( $watermarksrc );
            imagealphablending( $logoImage, true );

            $imageWidth=imagesx($image);
            $imageHeight=imagesy($image); 
            $logoWidth=imagesx($logoImage);
            $logoHeight=imagesy($logoImage);

            imagecopy($image, $logoImage, $imageWidth-$logoWidth, $imageHeight-$logoHeight, 0, 0, $logoWidth, $logoHeight);
			
			
            // Set type of image and send the output
            //header("Content-type: image/png");

            //imagepng($image);/*display image with watermark */
            $imgWM = imagepng($image, $new_name);/* save image with watermark */
			echo $imgWM==true?'Successful':'Failed';
            // Release memory
            imagedestroy($image);
            //imagedestroy($watermarksrc);
        }else{
			echo 'Upload fail';
		}
    }else{
        echo "ERROR: "; print_r($_FILES);
    }
} ?>